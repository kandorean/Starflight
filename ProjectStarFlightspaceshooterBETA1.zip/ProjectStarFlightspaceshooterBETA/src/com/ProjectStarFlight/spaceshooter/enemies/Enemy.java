package com.ProjectStarFlight.spaceshooter.enemies;

import java.awt.Graphics2D;

import com.ProjectStarFlight.spaceshooter.engine.StandardGameObject;
import com.ProjectStarFlight.spaceshooter.engine.StandardID;
import com.ProjectStarFlight.spaceshooter.engine.StdOps;

public abstract class Enemy extends StandardGameObject{
	
	protected int interval = StdOps.rand(0, 120);
	
	public Enemy(double x, double y){
		super(x, y, StandardID.Enemy);
	}


	public abstract void tick();

	public abstract void render(Graphics2D g2);
	
	public abstract void fireBullet();
}
