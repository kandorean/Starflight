/*     */ package com.ProjectStarFlight.spaceshooter.particles;
/*     */ 
/*     */ import com.ProjectStarFlight.spaceshooter.engine.StandardHandler;
/*     */ import com.ProjectStarFlight.spaceshooter.engine.StandardParticle;
/*     */ import com.ProjectStarFlight.spaceshooter.engine.StdOps;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DragParticle
/*     */   extends StandardParticle
/*     */ {
/*     */   public DragParticle(double x, double y, double life)
/*     */   {
/*  22 */     super(x, y, life);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  28 */     double d = StdOps.rand(0.0D, 6.283185307179586D);
/*  29 */     double h = StdOps.rand(0.05D, 2.5D);
/*     */     
/*  31 */     this.velX = (h * Math.sin(d));
/*  32 */     this.velY = (h * Math.cos(d));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  38 */     this.color = new Color(255, 255 - (int)this.death & 0x7F, 255 - (int)this.death & 0xFF, 255);
/*     */   }
/*     */   
/*     */   public DragParticle(double x, double y, double life, StandardHandler handler)
/*     */   {
/*  43 */     super(x, y, life, handler);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */     double d = StdOps.rand(0.0D, 6.283185307179586D);
/*  50 */     double h = StdOps.rand(0.05D, 2.5D);
/*     */     
/*  52 */     this.velX = (h * Math.sin(d));
/*  53 */     this.velY = (h * Math.cos(d));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */     this.color = new Color(255, 255 - (int)this.death & 0x7F, 255 - (int)this.death & 0xFF, 255);
/*     */   }
/*     */   
/*     */ 
/*     */   public DragParticle(double x, double y, double life, StandardHandler handler, Color c)
/*     */   {
/*  65 */     super(x, y, life, handler);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */     double d = StdOps.rand(0.0D, 6.283185307179586D);
/*  72 */     double h = StdOps.rand(0.05D, 2.5D);
/*     */     
/*  74 */     this.velX = (h * Math.sin(d));
/*  75 */     this.velY = (h * Math.cos(d));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     this.color = c;
/*     */   }
/*     */   
/*     */   public void tick()
/*     */   {
/*  88 */     if (this.alive)
/*     */     {
/*     */ 
/*     */ 
/*  92 */       this.width = ((int)(this.velX * this.velX * Math.signum(this.velX)) + 1);
/*  93 */       this.height = ((int)(this.velY * this.velY * Math.signum(this.velY)) + 1);
/*  94 */       this.x += this.velX;
/*  95 */       this.y += this.velY += 0.05D;
/*  96 */       this.alive = (System.nanoTime() - this.death <= 0L);
/*  97 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void render(Graphics2D g2)
/*     */   {
/* 105 */     if (!this.alive)
/* 106 */       return;
/* 107 */     int red = this.color.getRed();
/* 108 */     int green = this.color.getGreen();
/* 109 */     int blue = this.color.getBlue();
/* 110 */     int alpha = this.color.getAlpha();
/* 111 */     g2.setColor(new Color(red, green, blue, alpha));
/*     */     
/*     */ 
/* 114 */     g2.drawLine((int)this.x, (int)this.y, (int)(this.x + this.width), (int)(this.y + this.height));
/*     */   }
/*     */ }

