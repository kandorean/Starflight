/*    */ package com.ProjectStarFlight.spaceshooter.commands;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrintCommand
/*    */   extends Command
/*    */ {
/*    */   final long _StartTime;
/*    */   
/*    */   public PrintCommand(long time, int i)
/*    */   {
/* 15 */     this._Style = 1;
/* 16 */     this._StartTime = time;
/* 17 */     GAME_COMMANDS[i] = this;
/*    */   }
/*    */   
/*    */   public void execute() {
/* 21 */     System.out.println("Command executed at: " + (System.nanoTime() - this._StartTime) / 1.0E9D + "s.");
/*    */   }
/*    */ }

