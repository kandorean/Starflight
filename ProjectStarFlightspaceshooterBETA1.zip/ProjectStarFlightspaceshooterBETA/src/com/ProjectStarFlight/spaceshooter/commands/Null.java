/*    */ package com.ProjectStarFlight.spaceshooter.commands;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Null
/*    */   extends Command
/*    */ {
/*    */   public void execute()
/*    */   {
/* 15 */     System.out.println("No Command has been set.");
/*    */   }
/*    */ }

