/*     */ package com.ProjectStarFlight.spaceshooter.commands;
/*     */ 
/*     */ import com.ProjectStarFlight.spaceshooter.input.InputDevice;
/*     */ import com.ProjectStarFlight.spaceshooter.engine.StandardGame;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public abstract class Command
/*     */ {
/*     */   public static final int MAX_COMMANDS = 128;
/*     */   public static final int UNDEFINED = -1;
/*     */   public static final int ESC = 27;
/*     */   public static final int DEL = 127;
/*     */   public static final int STATE_MASK = 1;
/*     */   public static final int TOGGLE = 1;
/*     */   public static final int TOGGLE_MASK = 3;
/*     */   public static final int CONTINUOUS = 0;
/*  21 */   public static final Command NULL = new Null();
/*  22 */   protected static Command[] GAME_COMMANDS = new Command[''];
/*  23 */   public static int[] KEY_BINDS = new int[''];
/*  24 */   protected int _Style = 0;
/*  25 */   protected long _States = 0L;
/*  26 */   protected int _Bits = 0;
/*  27 */   protected boolean _On = false;
/*     */   
/*     */   public static void init()
/*     */   {
/*  43 */     Arrays.fill(KEY_BINDS, -1);
/*  44 */     Arrays.fill(GAME_COMMANDS, NULL);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void execute(int key)
/*     */   {
/*  88 */     if (key == -1)
/*  89 */       return;
/*  90 */     int index = key >> 1;
/*  91 */     key &= 0x1;
/*  92 */     Command command = GAME_COMMANDS[index];
/*  93 */     command._Bits = (command._Bits - (int)(command._States >>> 63) + key);
/*  94 */     command._States = (command._States << 1 | key);
/*     */     
/*  96 */     switch (command._Style)
/*     */     {
/*     */     case 0: 
/*  99 */       if (key == 1) {
/* 100 */         command._On = true;
/*     */       } else
/* 102 */         command._On = false;
/* 103 */       break;
/*     */     case 1: 
/* 105 */       if (((command._States ^ 0x3) & 0x3) == 1L)
/* 106 */         command._On = (!command._On);
/* 107 */       break;
/*     */     }
/*     */     
/*     */     
/* 111 */     if (command._On) {
/* 112 */       command.execute();
/*     */     }
/*     */   }
/*     */   

/*     */   public abstract void execute();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 132 */   public boolean on() { return this._On; }
/*     */   
/*     */   public void bind(InputDevice id, int key) {
/* 135 */     switch (key)
/*     */     {
/*     */     case 27: 
/* 138 */       return;
/*     */     case -1: 
/* 140 */       clear(id);
/* 141 */       return;
/*     */     }
/* 143 */     assign(id, key);
/*     */   }
/*     */   
/*     */ 
/*     */ 

/*     */ 
/*     */   protected void assign(InputDevice id, int key)
/*     */   {
/* 167 */     for (int i = 0; i < 128; i++)
/*     */     {
/* 169 */       if (KEY_BINDS[i] == key)
/*     */       {
/* 171 */         int commandIndex = id.get(KEY_BINDS[i], 2) >> 1;
/* 172 */         if (GAME_COMMANDS[commandIndex] == this) {
/* 173 */           return;
/*     */         }
/*     */         
/* 176 */         GAME_COMMANDS[commandIndex].clear(id);
/* 177 */         id.set(key, index(true) << 1);
/* 178 */         return;
/*     */       }
/*     */       
/* 181 */       if (KEY_BINDS[i] == -1)
/*     */       {
/* 183 */         KEY_BINDS[i] = (key | id.getDeviceMask());
/*     */         
/*     */ 
/*     */ 
/* 187 */         id.set(key, index(true) << 1);
/* 188 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   

/*     */ 
/*     */   public void clear(InputDevice id)
/*     */   {
/* 204 */     for (int i = 0; i < 128; i++)
/*     */     {
/*     */ 
/* 207 */       if (KEY_BINDS[i] != -1)
/*     */       {
/* 209 */         int commandIndex = id.get(KEY_BINDS[i], 2) >> 1;
/* 210 */         if (GAME_COMMANDS[commandIndex] == this)
/*     */         {
/* 212 */           id.set(KEY_BINDS[i], 0);
/* 213 */           KEY_BINDS[i] = -1;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int index(boolean insert)
/*     */   {
/* 232 */     for (int i = 0; i < 128; i++)
/*     */     {
/* 234 */       if (GAME_COMMANDS[i] == this)
/*     */       {
/* 236 */         return i;
/*     */       }
/*     */       
/* 239 */       if ((GAME_COMMANDS[i] == NULL) && (insert))
/*     */       {
/* 241 */         GAME_COMMANDS[i] = this;
/* 242 */         return i;
/*     */       }
/*     */     }
/* 245 */     return -1;
/*     */   }
/*     */   
/*     */   public static void tick(StandardGame stdGame)
/*     */   {
/* 250 */     for (int i = 0; i < 128; i++)
/*     */     {
/* 252 */       int key = KEY_BINDS[i];
/*     */       InputDevice id;
/* 254 */       if ((key & 0x80000000) == Integer.MIN_VALUE)
/*     */       { id = stdGame.getMouse();
 key ^= 0x80000000;
/*     */       }
/*     */       else
/*     */       {
/* 261 */         id = stdGame.getKeyboard();
/*     */       }
/* 263 */       key = id.get(key, 0);
/* 264 */       execute(key);
/*     */     }
/*     */   }
/*     */ }

