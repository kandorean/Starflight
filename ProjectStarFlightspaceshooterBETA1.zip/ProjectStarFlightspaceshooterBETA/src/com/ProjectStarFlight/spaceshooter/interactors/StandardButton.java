/*     */ package com.ProjectStarFlight.spaceshooter.interactors;
/*     */ 
/*     */ import com.ProjectStarFlight.spaceshooter.engine.StdOps;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardButton
/*     */   extends Interactor
/*     */   implements MouseListener, KeyListener, MouseMotionListener
/*     */ {
/*  27 */   public boolean pressed = false;
/*  28 */   public boolean mouseOver = false;
/*  29 */   private boolean isImage = false;
/*     */   
/*     */   private String text;
/*     */   private Color color;
/*     */   private String fileLocation;
/*     */   private BufferedImage image;
/*     */   
/*     */   public StandardButton() {}
/*     */   
/*     */   public StandardButton(int x, int y)
/*     */   {
/*  40 */     super((short)x, (short)y);
/*     */   }
/*     */   
/*     */   public StandardButton(int x, int y, int width, int height) {
/*  44 */     super((short)x, (short)y, (short)width, (short)height);
/*     */   }
/*     */   
/*     */   public StandardButton(int x, int y, int width, int height, Color color) {
/*  48 */     super((short)x, (short)y, (short)width, (short)height);
/*  49 */     this.color = color;
/*     */   }
/*     */   
/*     */   public StandardButton(int x, int y, int width, int height, String text, Color color) {
/*  53 */     super((short)x, (short)y, (short)width, (short)height);
/*  54 */     this.text = text;
/*  55 */     this.color = color;
/*     */   }
/*     */   
/*     */   public StandardButton(int x, int y, int width, int height, int red, int green, int blue) {
/*  59 */     super((short)x, (short)y, (short)width, (short)height);
/*  60 */     this.color = new Color(red, green, blue);
/*     */   }
/*     */   
/*     */   public StandardButton(int x, int y, String fileLocation) {
/*  64 */     super((short)x, (short)y);
/*     */     try
/*     */     {
/*  67 */       this.image = ImageIO.read(new File(fileLocation));
/*     */     } catch (IOException e) {
/*  69 */       e.printStackTrace();
/*     */     }
/*     */     
/*  72 */     setWidth((short)this.image.getWidth());
/*  73 */     setHeight((short)this.image.getHeight());
/*  74 */     this.isImage = true;
/*     */   }
/*     */   
/*     */   public StandardButton(int x, int y, BufferedImage image) {
/*  78 */     super((short)x, (short)y);
/*     */     
/*  80 */     this.image = image;
/*     */     
/*  82 */     setWidth((short)this.image.getWidth());
/*  83 */     setHeight((short)this.image.getHeight());
/*  84 */     this.isImage = true;
/*     */   }
/*     */   
/*     */   public void tick()
/*     */   {
/*  89 */     setX((short)(getX() + getVelX()));
/*  90 */     setY((short)(getY() + getVelY()));
/*     */     
/*     */ 
/*  93 */     if (this.mouseOver) {
/*  94 */       this.color = Color.green;
/*  95 */       if (this.pressed) {
/*  96 */         this.color = Color.BLUE;
/*     */       } else {
/*  98 */         this.color = Color.GREEN;
/*     */       }
/*     */     } else {
/* 101 */       this.color = Color.red;
/*     */     }
/*     */   }
/*     */   
/*     */   public void render(Graphics2D g2)
/*     */   {
/* 107 */     if (this.isImage) {
/* 108 */       g2.drawImage(this.image, getX(), getY(), null);
/*     */     } else {
/* 110 */       g2.setColor(this.color);
/* 111 */       g2.fillRect(getX(), getY(), getWidth(), getHeight());
/*     */       
/* 113 */       g2.setColor(Color.WHITE);
/*     */       
/* 115 */       if (this.text != null) {
/* 116 */         g2.drawString(this.text, getX() + getHeight() / 2, getY() + getHeight() / 2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent e)
/*     */   {
/* 123 */     if (isInteractable()) {
/* 124 */       System.out.println("Mouse clicked button.");
/*     */       
/*     */ 
/* 127 */       if (StdOps.mouseOver(e.getX(), e.getY(), getX(), getY(), getWidth(), getHeight())) {
/* 128 */         this.pressed = true;
/*     */       } else {
/* 130 */         this.pressed = false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void mouseReleased(MouseEvent e)
/*     */   {
/* 138 */     if (isInteractable()) {
/* 139 */       System.out.println("Mouse released button.");
/*     */       
/*     */ 
/* 142 */       if (StdOps.mouseOver(e.getX(), e.getY(), getX(), getY(), getWidth(), getHeight())) {
/* 143 */         this.pressed = false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void mouseMoved(MouseEvent e)
/*     */   {
/* 151 */     if (isInteractable())
/*     */     {
/* 153 */       if (StdOps.mouseOver(e.getX(), e.getY(), getX(), getY(), getWidth(), getHeight())) {
/* 154 */         this.mouseOver = true;
/*     */       }
/*     */       else {
/* 157 */         this.mouseOver = false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mouseExited(MouseEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mouseDragged(MouseEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void keyTyped(KeyEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void keyPressed(KeyEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void keyReleased(KeyEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileLocation()
/*     */   {
/* 203 */     return this.fileLocation;
/*     */   }
/*     */   
/*     */   public void setFileLocation(String fileLocation) {
/* 207 */     this.fileLocation = fileLocation;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 211 */     return "StandardButton Object: X: " + getX() + "\tY: " + getY() + "\tWidth: " + getWidth() + "\tHeight: " + getHeight() + "\tText: " + this.text + "\tColor: " + this.color;
/*     */   }
/*     */ }


