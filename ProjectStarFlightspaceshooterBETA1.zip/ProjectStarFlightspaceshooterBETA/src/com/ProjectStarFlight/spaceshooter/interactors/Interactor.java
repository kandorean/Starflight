/*     */ package com.ProjectStarFlight.spaceshooter.interactors;
/*     */ 
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Interactor
/*     */ {
/*     */   private short x;
/*     */   private short y;
/*     */   private short velX;
/*     */   private short velY;
/*     */   private short width;
/*     */   private short height;
/*  17 */   private boolean interactable = true;
/*     */   
/*     */ 
/*     */   public Interactor() {}
/*     */   
/*     */   public Interactor(short x, short y)
/*     */   {
/*  24 */     this.x = x;
/*  25 */     this.y = y;
/*     */   }
/*     */   
/*     */   public Interactor(short x, short y, boolean interactable) {
/*  29 */     this.x = x;
/*  30 */     this.y = y;
/*  31 */     this.interactable = interactable;
/*     */   }
/*     */   
/*     */   public Interactor(short x, short y, short width, short height) {
/*  35 */     this.x = x;
/*  36 */     this.y = y;
/*  37 */     this.width = width;
/*  38 */     this.height = height;
/*     */   }
/*     */   
/*     */   public Interactor(short x, short y, short width, short height, boolean interactable) {
/*  42 */     this.x = x;
/*  43 */     this.y = y;
/*  44 */     this.width = width;
/*  45 */     this.height = height;
/*  46 */     this.interactable = interactable;
/*     */   }
/*     */   
/*     */   public abstract void tick();
/*     */   
/*     */   public abstract void render(Graphics2D paramGraphics2D);
/*     */   
/*     */   public Rectangle getBounds() {
/*  54 */     return new Rectangle(this.x, this.y, this.width, this.height);
/*     */   }
/*     */   
/*     */   public short getX() {
/*  58 */     return this.x;
/*     */   }
/*     */   
/*     */   public void setX(short x) {
/*  62 */     this.x = x;
/*     */   }
/*     */   
/*     */   public short getY() {
/*  66 */     return this.y;
/*     */   }
/*     */   
/*     */   public void setY(short y) {
/*  70 */     this.y = y;
/*     */   }
/*     */   
/*     */   public short getVelX() {
/*  74 */     return this.velX;
/*     */   }
/*     */   
/*     */   public void setVelX(short velX) {
/*  78 */     this.velX = velX;
/*     */   }
/*     */   
/*     */   public short getVelY() {
/*  82 */     return this.velY;
/*     */   }
/*     */   
/*     */   public void setVelY(short velY) {
/*  86 */     this.velY = velY;
/*     */   }
/*     */   
/*     */   public short getWidth() {
/*  90 */     return this.width;
/*     */   }
/*     */   
/*     */   public void setWidth(short width) {
/*  94 */     this.width = width;
/*     */   }
/*     */   
/*     */   public short getHeight() {
/*  98 */     return this.height;
/*     */   }
/*     */   
/*     */   public void setHeight(short height) {
/* 102 */     this.height = height;
/*     */   }
/*     */   
/*     */   public boolean isInteractable() {
/* 106 */     return this.interactable;
/*     */   }
/*     */   
/*     */   public void setInteractable(boolean interactable) {
/* 110 */     this.interactable = interactable;
/*     */   }
/*     */ }

