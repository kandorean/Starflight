/*    */ package com.ProjectStarFlight.spaceshooter.interactors;
/*    */ 
/*    */ import java.awt.Graphics2D;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardHandlerInteractor
/*    */ {
/*    */   private ArrayList<Interactor> interactors;
/*    */   
/*    */   public StandardHandlerInteractor()
/*    */   {
/* 18 */     this.interactors = new ArrayList();
/*    */   }
/*    */   
/*    */   public void tick() {
/* 22 */     for (int i = 0; i < this.interactors.size(); i++) {
/* 23 */       ((Interactor)this.interactors.get(i)).tick();
/*    */     }
/*    */   }
/*    */   
/*    */   public void render(Graphics2D g2) {
/* 28 */     for (int i = 0; i < this.interactors.size(); i++) {
/* 29 */       ((Interactor)this.interactors.get(i)).render(g2);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addInteractor(Interactor actor) {
/* 34 */     this.interactors.add(actor);
/*    */   }
/*    */   
/*    */   public void removeInteractor(Interactor actor) {
/* 38 */     this.interactors.remove(actor);
/*    */   }
/*    */   
/*    */   public int size() {
/* 42 */     return this.interactors.size();
/*    */   }
/*    */   
/*    */   public Interactor get(int i) {
/* 46 */     return (Interactor)this.interactors.get(i);
/*    */   }
/*    */ }


