package com.ProjectStarFlight.spaceshooter.input;

public abstract interface InputDevice
{
  public static final int COMMAND_MASK = 254;
  public static final int STATE_MASK = 1;
  public static final int MOUSE_MASK = Integer.MIN_VALUE;
  public static final int KEYBOARD_MASK = 0;
  public static final int STATE = 1;
  public static final int COMMAND = 2;
  public static final int BOTH = 0;
  public static final int UNDEFINED = -1;
  public static final int TOGGLE = 1;
  public static final int CONTINUOUS = 0;
  
  public abstract byte[] getBytes();
  
  public abstract int getDeviceMask();
  
  public abstract void set(int paramInt1, int paramInt2);
  
  public abstract int get(int paramInt1, int paramInt2);
  
  public abstract boolean stateOn(int paramInt);
}


