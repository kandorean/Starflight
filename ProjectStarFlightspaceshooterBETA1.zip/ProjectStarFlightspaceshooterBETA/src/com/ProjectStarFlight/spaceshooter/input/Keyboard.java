/*    */ package com.ProjectStarFlight.spaceshooter.input;
/*    */ 
/*    */ import java.awt.event.KeyEvent;
/*    */ import java.awt.event.KeyListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Keyboard
/*    */   implements KeyListener, InputDevice
/*    */ {
/*    */   public final byte[] _Keys;
/*    */   
/*    */   public Keyboard()
/*    */   {
/* 23 */     this._Keys = new byte[65536];
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getDeviceMask()
/*    */   {
/* 30 */     return 0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public byte[] getBytes()
/*    */   {
/* 37 */     return this._Keys;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void set(int k, int v)
/*    */   {
/* 44 */     if ((k >= 0) && (k < this._Keys.length))
/*    */     {
/* 46 */       this._Keys[k] = ((byte)v);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int get(int code, int type)
/*    */   {
/* 54 */     if ((code >= 0) && (code < this._Keys.length))
/*    */     {
/* 56 */       switch (type)
/*    */       {
/*    */       case 1: 
/* 59 */         return this._Keys[code] & 0x1;
/*    */       
/*    */ 
/*    */       case 2: 
/* 63 */         return this._Keys[code] & 0xFE;
/*    */       }
/* 65 */       return this._Keys[code];
/*    */     }
/*    */     
/* 68 */     return -1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean stateOn(int code)
/*    */   {
/* 75 */     if ((code >= 0) && (code < this._Keys.length))
/*    */     {
/* 77 */       return (this._Keys[code] & 0x1) != 0;
/*    */     }
/* 79 */     return false;
/*    */   }
/*    */   
/*    */   public void keyPressed(KeyEvent e) {
/* 83 */     int code = e.getKeyCode();
/* 84 */     if ((code >= 0) && (code < this._Keys.length))
/*    */     {
/* 86 */       int tmp23_22 = code; byte[] tmp23_19 = this._Keys;tmp23_19[tmp23_22] = ((byte)(tmp23_19[tmp23_22] | 0x1));
/*    */     }
/*    */   }
/*    */   
/*    */   public void keyReleased(KeyEvent e) {
/* 91 */     int code = e.getKeyCode();
/* 92 */     if ((code >= 0) && (code < this._Keys.length))
/*    */     {
/* 94 */       int tmp23_22 = code; byte[] tmp23_19 = this._Keys;tmp23_19[tmp23_22] = ((byte)(tmp23_19[tmp23_22] & 0xFFFFFFFE));
/*    */     }
/*    */   }
/*    */   
/*    */   public void keyTyped(KeyEvent e) {}
/*    */ }
