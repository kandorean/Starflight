/*    */ package com.ProjectStarFlight.spaceshooter.input;
/*    */ 
/*    */ import com.ProjectStarFlight.spaceshooter.commands.Command;
/*    */ import com.ProjectStarFlight.spaceshooter.engine.StandardAnimator;
/*    */ import com.ProjectStarFlight.spaceshooter.engine.StandardGameObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Movement
/*    */   extends Command
/*    */ {
/*    */   public StandardGameObject player;
/*    */   public StandardAnimator animator;
/*    */   public float deltaX;
/*    */   public float deltaY;
/*    */   
/*    */   public Movement(StandardGameObject sgo, StandardAnimator sa, float deltax, float deltay)
/*    */   {
/* 35 */     this.player = sgo;
/* 36 */     this.animator = sa;
/* 37 */     this.deltaX = deltax;
/* 38 */     this.deltaY = deltay;
/*    */   }
/*    */   
/*    */   public void execute()
/*    */   {
/* 43 */     if (this.animator != null)
/* 44 */       this.animator.animate();
/* 45 */     this.player.setVelX(this.player.getVelX() + this.deltaX);
/* 46 */     this.player.setVelY(this.player.getVelY() + this.deltaY);
/*    */   }
/*    */ }

