/*     */ package com.ProjectStarFlight.spaceshooter.input;
/*     */ 
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mouse
/*     */   implements MouseListener, MouseMotionListener, InputDevice
/*     */ {
/*     */   public final byte[] _Buttons;
/*  22 */   public int x = 0;
/*  23 */   public int y = 0;
/*     */   
/*     */   public Mouse() {
/*  26 */     this._Buttons = new byte[16];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getDeviceMask()
/*     */   {
/*  33 */     return Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/*  40 */     return this._Buttons;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void set(int k, int v)
/*     */   {
/*  47 */     if ((k >= 0) && (k < this._Buttons.length))
/*     */     {
/*  49 */       this._Buttons[k] = ((byte)v);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int get(int code, int type)
/*     */   {
/*  57 */     if ((code >= 0) && (code < this._Buttons.length))
/*     */     {
/*  59 */       switch (type)
/*     */       {
/*     */       case 1: 
/*  62 */         return this._Buttons[code] & 0x1;
/*     */       
/*     */ 
/*     */       case 2: 
/*  66 */         return this._Buttons[code] & 0xFE;
/*     */       }
/*  68 */       return this._Buttons[code];
/*     */     }
/*     */     
/*  71 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean stateOn(int code)
/*     */   {
/*  78 */     if ((code >= 0) && (code < this._Buttons.length))
/*     */     {
/*  80 */       return (this._Buttons[code] & 0x1) != 0;
/*     */     }
/*  82 */     return false;
/*     */   }
/*     */   
/*     */   public void update(MouseEvent e) {
/*  86 */     this.x = e.getX();
/*  87 */     this.y = e.getY();
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent e) {
/*  91 */     update(e);
/*  92 */     int code = e.getButton();
/*  93 */     if ((code >= 0) && (code < this._Buttons.length))
/*     */     {
/*  95 */       int tmp28_27 = code; byte[] tmp28_24 = this._Buttons;tmp28_24[tmp28_27] = ((byte)(tmp28_24[tmp28_27] | 0x1));
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {
/* 100 */     update(e);
/* 101 */     int code = e.getButton();
/* 102 */     if ((code >= 0) && (code < this._Buttons.length))
/*     */     {
/* 104 */       int tmp28_27 = code; byte[] tmp28_24 = this._Buttons;tmp28_24[tmp28_27] = ((byte)(tmp28_24[tmp28_27] & 0xFFFFFFFE));
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {
/* 109 */     update(e);
/*     */   }
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {
/* 113 */     update(e);
/*     */   }
/*     */   
/*     */   public void mouseExited(MouseEvent e) {
/* 117 */     update(e);
/*     */   }
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {
/* 121 */     update(e);
/*     */   }
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {
/* 125 */     update(e);
/*     */   }
/*     */ }


