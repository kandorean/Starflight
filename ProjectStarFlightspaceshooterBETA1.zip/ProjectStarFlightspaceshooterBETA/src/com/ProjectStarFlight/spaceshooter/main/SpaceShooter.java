package com.ProjectStarFlight.spaceshooter.main;

import java.awt.image.BufferedImage;

import com.ProjectStarFlight.spaceshooter.enemies.EnemyShip;
import com.ProjectStarFlight.spaceshooter.engine.StandardDraw;
import com.ProjectStarFlight.spaceshooter.engine.StandardGame;
import com.ProjectStarFlight.spaceshooter.engine.StandardHandler;
import com.ProjectStarFlight.spaceshooter.engine.StdOps;

public class SpaceShooter extends StandardGame{
	


	//Inits the new handler to handle collisions
	public static StandardHandler gssh;
	
	//Inits the objects in the game
	private Player player;
	
	//Background init
	private static BufferedImage bg = null;
	
	//Etc instance variables
	public static int score = 0;
	
	public SpaceShooter(int w, int h){
		super(w, h, "Project Starflight: Spaceshooter");
		this.consoleFPS = false;
		
		SpaceShooter.bg = StdOps.loadImage("Resources/bg.png");
		
		
		SpaceShooter.gssh = new SpaceShooterHandler();
		
		this.player = new Player(300, 720, this);
		
		
		SpaceShooter.gssh.addEntity(this.player);
		
		this.addListener(player);
		
		this.StartGame();
	}
	
	public void tick(){
		if(SpaceShooter.gssh.size() < 20)
			SpaceShooter.gssh.addEntity(new EnemyShip(StdOps.rand(0, 760), StdOps.rand(-200, -50)));
		
		StandardHandler.Handler(gssh);
		
		SpaceShooter.score++;
	}
	
	public void render(){
		StandardDraw.image(SpaceShooter.bg, 0, 0); 
		StandardDraw.Handler(gssh);
		
	}
	
	public static void main(String[] args) {
		new SpaceShooter(800,800);
	}
}
