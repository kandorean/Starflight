package com.ProjectStarFlight.spaceshooter.main;

public class Level {

	public Level(){
		
	}
}
