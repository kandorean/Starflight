/*     */ package com.ProjectStarFlight.spaceshooter.engine;
/*     */ 
/*     */ import com.ProjectStarFlight.spaceshooter.particles.DragParticle;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StandardGameObject
/*     */ {
/*     */   public double x;
/*     */   public double y;
/*     */   public double velX;
/*     */   public double velY;
/*     */   public int width;
/*     */   public int height;
/*     */   public double health;
/*  48 */   public static double gravity = 0.25D;
/*     */   
/*     */ 
/*     */   private String fileLocation;
/*     */   
/*     */   public StandardID id;
/*     */   
/*     */   public BufferedImage currentSprite;
/*     */   
/*     */   public StandardAnimator activeAnimation;
/*     */   
/*  59 */   private boolean interactable = false;
/*     */   
/*  61 */   public long death = 0L;
/*     */   
/*     */ 
/*  64 */   public boolean alive = true;
/*  65 */   public boolean jumping = false;
/*  66 */   public boolean falling = false;
/*  67 */   public boolean standing = false;
/*  68 */   public boolean ducking = false;
/*  69 */   public boolean attacking = false;
/*  70 */   public boolean hurt = false;
/*  71 */   public boolean firstDeathPass = true;
/*  72 */   public boolean fdp = true;
/*     */   public Direction lastDir;
/*     */   public StandardGameObject() {}
/*     */   
/*  76 */   public static enum Direction { Left,  Right;
/*     */   }
/*     */   
/*  79 */   public StandardID ignore = StandardID.Object;
/*     */   
/*  81 */   public StandardParticleHandler deathParticles = null;
/*     */   
/*     */ 
/*  84 */   public BufferedImage[] leftImages = null; public BufferedImage[] rightImages = null;
/*  85 */   public BufferedImage[] attackLeftImages = null; public BufferedImage[] attackRightImages = null;
/*     */   
/*  87 */   public StandardAnimator lefts = null; public StandardAnimator rights = null;
/*  88 */   public StandardAnimator aLefts = null; public StandardAnimator aRights = null;
/*     */   
/*     */ 
/*     */   private Rectangle bounds;
/*     */   
/*     */ 
/*     */ 
/*     */   public StandardGameObject(double x, double y, StandardID id)
/*     */   {
/*  97 */     this.x = x;
/*  98 */     this.y = y;
/*     */     
/* 100 */     this.id = id;
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, double y, StandardID id, boolean interactable) {
/* 104 */     this.x = x;
/* 105 */     this.y = y;
/*     */     
/* 107 */     this.id = id;
/* 108 */     this.interactable = interactable;
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, double y, int width, int height) {
/* 112 */     this.x = x;
/* 113 */     this.y = y;
/* 114 */     this.width = width;
/* 115 */     this.height = height;
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, double y, int width, int height, StandardID id) {
/* 119 */     this.x = x;
/* 120 */     this.y = y;
/* 121 */     this.width = width;
/* 122 */     this.height = height;
/* 123 */     this.id = id;
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, int y, int width, int height, StandardID id, boolean interactable) {
/* 127 */     this.x = x;
/* 128 */     this.y = y;
/* 129 */     this.width = width;
/* 130 */     this.height = height;
/* 131 */     this.id = id;
/* 132 */     this.interactable = interactable;
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, double y, String fileLocation) {
/* 136 */     this.x = x;
/* 137 */     this.y = y;
/*     */     
/* 139 */     this.fileLocation = fileLocation;
/*     */     try
/*     */     {
/* 142 */       this.currentSprite = ImageIO.read(new File(this.fileLocation));
/*     */     } catch (IOException e) {
/* 144 */       e.printStackTrace();
/*     */     }
/*     */     
/* 147 */     this.width = this.currentSprite.getWidth();
/* 148 */     this.height = this.currentSprite.getHeight();
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, double y, String fileLocation, boolean interactable) {
/* 152 */     this.x = x;
/* 153 */     this.y = y;
/*     */     
/* 155 */     this.fileLocation = fileLocation;
/*     */     try
/*     */     {
/* 158 */       this.currentSprite = ImageIO.read(new File(this.fileLocation));
/*     */     } catch (IOException e) {
/* 160 */       e.printStackTrace();
/*     */     }
/*     */     
/* 163 */     this.width = this.currentSprite.getWidth();
/* 164 */     this.height = this.currentSprite.getHeight();
/*     */     
/* 166 */     this.interactable = interactable;
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, double y, String fileLocation, StandardID id) {
/* 170 */     this.x = x;
/* 171 */     this.y = y;
/*     */     
/* 173 */     this.fileLocation = fileLocation;
/*     */     try
/*     */     {
/* 176 */       this.currentSprite = ImageIO.read(new File(this.fileLocation));
/*     */     } catch (IOException e) {
/* 178 */       e.printStackTrace();
/*     */     }
/*     */     
/* 181 */     this.width = this.currentSprite.getWidth();
/* 182 */     this.height = this.currentSprite.getHeight();
/* 183 */     this.id = id;
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, double y, String fileLocation, StandardID id, boolean interactable) {
/* 187 */     this.x = x;
/* 188 */     this.y = y;
/*     */     
/* 190 */     this.fileLocation = fileLocation;
/*     */     try
/*     */     {
/* 193 */       this.currentSprite = ImageIO.read(new File(this.fileLocation));
/*     */     } catch (IOException e) {
/* 195 */       e.printStackTrace();
/*     */     }
/*     */     
/* 198 */     this.width = this.currentSprite.getWidth();
/* 199 */     this.height = this.currentSprite.getHeight();
/* 200 */     this.id = id;
/*     */     
/* 202 */     this.interactable = interactable;
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, double y, BufferedImage image) {
/* 206 */     this.x = x;
/* 207 */     this.y = y;
/* 208 */     this.currentSprite = image;
/*     */     
/* 210 */     this.width = this.currentSprite.getWidth();
/* 211 */     this.height = this.currentSprite.getHeight();
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, double y, BufferedImage image, StandardID id) {
/* 215 */     this.x = x;
/* 216 */     this.y = y;
/* 217 */     this.currentSprite = image;
/*     */     
/* 219 */     this.width = this.currentSprite.getWidth();
/* 220 */     this.height = this.currentSprite.getHeight();
/* 221 */     this.id = id;
/*     */   }
/*     */   
/*     */   public StandardGameObject(double x, double y, BufferedImage image, StandardID id, boolean interactable) {
/* 225 */     this.x = x;
/* 226 */     this.y = y;
/* 227 */     this.currentSprite = image;
/*     */     
/* 229 */     this.width = this.currentSprite.getWidth();
/* 230 */     this.height = this.currentSprite.getHeight();
/* 231 */     this.id = id;
/*     */     
/* 233 */     this.interactable = interactable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void tick();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void render(Graphics2D paramGraphics2D);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void attack() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void collide(StandardGameObject sgo)
/*     */   {
/* 261 */     if (sgo.getId() == StandardID.Projectile) {
/* 262 */       sgo.collide(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkDeath()
/*     */   {
/* 277 */     if (this.health <= 0.0D) {
/* 278 */       this.alive = false;
/* 279 */       if (this.firstDeathPass) {
/* 280 */         this.velX = 0.0D;
/* 281 */         this.deathParticles = new StandardParticleHandler(20);
/* 282 */         for (int i = 0; i < this.deathParticles.MAX_PARTICLES; i++)
/* 283 */           this.deathParticles.addEntity(new DragParticle(this.x, this.y, 1.5D));
/*     */       }
/* 285 */       this.firstDeathPass = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public void hurtEntity(int dmg)
/*     */   {
/* 291 */     this.health = (Math.signum(dmg) == -1.0F ? this.health + dmg : this.health - dmg);
/*     */     
/* 293 */     if (this.health <= 0.0D) { return;
/*     */     }
/* 295 */     if (this.lastDir == Direction.Right) {
/* 296 */       this.velX = -10.0D;
/*     */     }
/*     */     else
/*     */     {
/* 300 */       this.velX = 10.0D;
/*     */     }
/*     */   }
/*     */   
/*     */   public double getX() {
/* 305 */     return this.x;
/*     */   }
/*     */   
/*     */   public void setX(double x) {
/* 309 */     this.x = x;
/*     */   }
/*     */   
/*     */   public double getY() {
/* 313 */     return this.y;
/*     */   }
/*     */   
/*     */   public void setY(double y) {
/* 317 */     this.y = y;
/*     */   }
/*     */   
/*     */   public double getVelX() {
/* 321 */     return this.velX;
/*     */   }
/*     */   
/*     */   public void setVelX(double velX) {
/* 325 */     this.velX = velX;
/*     */   }
/*     */   
/*     */   public double getVelY() {
/* 329 */     return this.velY;
/*     */   }
/*     */   
/*     */   public void setVelY(double velY) {
/* 333 */     this.velY = velY;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 337 */     return this.width;
/*     */   }
/*     */   
/*     */   public void setWidth(int width) {
/* 341 */     this.width = width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 345 */     return this.height;
/*     */   }
/*     */   
/*     */   public void setHeight(int height) {
/* 349 */     this.height = height;
/*     */   }
/*     */   
/*     */   public String getFileLocation() {
/* 353 */     return this.fileLocation;
/*     */   }
/*     */   
/*     */   public void setFileLocation(String fileLocation) {
/* 357 */     this.fileLocation = fileLocation;
/*     */   }
/*     */   
/*     */   public BufferedImage getCurrentSprite() {
/* 361 */     return this.currentSprite;
/*     */   }
/*     */   
/*     */   public void setCurrentSprite(BufferedImage currentSprite) {
/* 365 */     this.currentSprite = currentSprite;
/*     */   }
/*     */   
/*     */   public StandardID getId() {
/* 369 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(StandardID id) {
/* 373 */     this.id = id;
/*     */   }
/*     */   
/*     */   public void setInteractable(boolean interactable) {
/* 377 */     this.interactable = interactable;
/*     */   }
/*     */   
/*     */   public boolean isInteractable() {
/* 381 */     return this.interactable;
/*     */   }
/*     */   
/*     */   public StandardAnimator getAnimation() {
/* 385 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAnimating(boolean bool) {}
/*     */   
/*     */   public Rectangle getBounds(int nX, int nY, int nW, int nH)
/*     */   {
/* 393 */     this.bounds = new Rectangle((int)this.x + nX, (int)this.y + nY, this.width + nW, this.height + nH);
/* 394 */     return this.bounds;
/*     */   }
/*     */   
/*     */   public Rectangle getBounds() {
/* 398 */     this.bounds = new Rectangle((int)this.x, (int)this.y, this.width, this.height);
/* 399 */     return this.bounds;
/*     */   }
/*     */   
/*     */   public Rectangle getLeftBounds() {
/* 403 */     return new Rectangle((int)this.x, (int)this.y, 1, this.height);
/*     */   }
/*     */   
/*     */   public Rectangle getRightBounds() {
/* 407 */     return new Rectangle((int)this.x + this.width, (int)this.y, 1, this.height);
/*     */   }
/*     */   
/*     */   public Rectangle getTopBounds() {
/* 411 */     return new Rectangle((int)this.x, (int)this.y, this.width, 3);
/*     */   }
/*     */   
/*     */   public Rectangle getBottomBounds() {
/* 415 */     return new Rectangle((int)this.x, (int)this.y + this.height, this.width, 1);
/*     */   }
/*     */   
/*     */   public boolean alive() {
/* 419 */     return this.alive;
/*     */   }
/*     */   
/*     */   public void setAlive(boolean alive) {
/* 423 */     this.alive = alive;
/*     */   }
/*     */   
/*     */   public long getDeath() {
/* 427 */     return this.death;
/*     */   }
/*     */   
/*     */   public void setDeath(long death) {
/* 431 */     this.death = death;
/*     */   }
/*     */   
/*     */   public double getRestitution() {
/* 435 */     return 1.0D;
/*     */   }
/*     */   
/* 438 */   public double getGravity() { return gravity; }
/*     */   
/*     */   public boolean isAlive()
/*     */   {
/* 442 */     return this.alive;
/*     */   }
/*     */   
/*     */   public double getHealth() {
/* 446 */     return this.health;
/*     */   }
/*     */   
/*     */   public void setHealth(int health) {
/* 450 */     this.health = health;
/*     */   }
/*     */   
/*     */   public boolean isJumping() {
/* 454 */     return this.jumping;
/*     */   }
/*     */   
/*     */   public void setJumping(boolean jumping) {
/* 458 */     this.jumping = jumping;
/*     */   }
/*     */   
/*     */   public boolean isFalling() {
/* 462 */     return this.falling;
/*     */   }
/*     */   
/*     */   public void setFalling(boolean falling) {
/* 466 */     this.falling = falling;
/*     */   }
/*     */   
/*     */   public boolean isStanding() {
/* 470 */     return this.standing;
/*     */   }
/*     */   
/*     */   public void setStanding(boolean standing) {
/* 474 */     this.standing = standing;
/*     */   }
/*     */   
/*     */   public static void setGravity(double gravity) {
/* 478 */     gravity = gravity;
/*     */   }
/*     */ }

