/*     */ package com.ProjectStarFlight.spaceshooter.engine;
/*     */ 
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import javax.imageio.ImageIO;
/*     */ 

/*     */ public abstract class StandardLevel
/*     */ {
/*     */   private String fileLocation;
/*     */   private BufferedImage levelData;
/*     */   private String bgImagePath;
/*     */   private BufferedImage bgImage;
/*     */   public StandardHandler stdHandler;
/*     */   
/*     */   public StandardLevel(String fileLocation, String bgImagePath, StandardHandler stdHandler)
/*     */   {
/*  49 */     this.fileLocation = fileLocation;
/*  50 */     this.bgImagePath = bgImagePath;
/*  51 */     this.stdHandler = stdHandler;
/*     */     try
/*     */     {
/*  54 */       this.levelData = ImageIO.read(new File(this.fileLocation));
/*  55 */       this.bgImage = ImageIO.read(new File(this.bgImagePath));
/*     */     } catch (Exception e) {
/*  57 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   

/*     */   public abstract void loadLevelData();
/*     */   
/*     */ 

/*     */ 
/*     */ 
/*     */   public abstract void tick();
/*     */   

/*     */ 
/*     */   public abstract void render(Graphics2D paramGraphics2D);

/*     */   public String getFileLocation()
/*     */   {
/* 102 */     return this.fileLocation;
/*     */   }
/*     */   
/*     */   public void setFileLocation(String fileLocation) {
/* 106 */     this.fileLocation = fileLocation;
/*     */   }
/*     */   
/*     */   public BufferedImage getLevelData() {
/* 110 */     return this.levelData;
/*     */   }
/*     */   
/*     */   public void setLevelData(BufferedImage levelData) {
/* 114 */     this.levelData = levelData;
/*     */   }
/*     */   
/*     */   public String getBgImagePath() {
/* 118 */     return this.bgImagePath;
/*     */   }
/*     */   
/*     */   public void setBgImagePath(String bgImagePath) {
/* 122 */     this.bgImagePath = bgImagePath;
/*     */   }
/*     */   
/*     */   public BufferedImage getBgImage() {
/* 126 */     return this.bgImage;
/*     */   }
/*     */   
/*     */   public void setBgImage(BufferedImage bgImage) {
/* 130 */     this.bgImage = bgImage;
/*     */   }
/*     */ }

