/*    */ package com.ProjectStarFlight.spaceshooter.engine;
/*    */ 
/*    */ import java.awt.Graphics2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardCamera
/*    */   extends StandardGameObject
/*    */ {
/*    */   public StandardGameObject subject;
/* 13 */   public double snap = 1.0D;
/* 14 */   public int vpw = 0; public int vph = 0; public int maxX = Integer.MAX_VALUE; public int maxY = this.maxX; public int minX = Integer.MIN_VALUE; public int minY = this.minX;
/*    */   
/*    */   public StandardCamera(StandardGameObject sgo, double snap, int vpw, int vph) {
/* 17 */     super(sgo.x, sgo.y, StandardID.Camera);
/* 18 */     this.vpw = (vpw >> 1);
/* 19 */     this.vph = (vph >> 1);
/* 20 */     this.subject = sgo;
/* 21 */     this.snap = snap;
/*    */   }
/*    */   
/*    */   public void restrict(int maxx, int maxy, int minx, int miny) {
/* 25 */     this.maxX = maxx;
/* 26 */     this.maxY = maxy;
/* 27 */     this.minX = minx;
/* 28 */     this.minY = miny;
/*    */   }
/*    */   
/*    */ 
/*    */   public void tick()
/*    */   {
/* 34 */     tickX();
/* 35 */     tickY();
/*    */   }
/*    */   
/*    */   public void render(Graphics2D g2)
/*    */   {
/* 40 */     g2.translate(-this.x + this.vpw, -this.y + this.vph);
/*    */   }
/*    */   
/*    */   public void tickX() {
/* 44 */     double location = this.subject.x;
/* 45 */     if (location > this.maxX) {
/* 46 */       location = this.maxX;
/*    */     }
/* 48 */     else if (location < this.minX)
/* 49 */       location = this.minX;
/* 50 */     this.velX = ((location - this.x) * this.snap);
/* 51 */     this.x += this.velX;
/*    */   }
/*    */   
/*    */   public void tickY() {
/* 55 */     double location = this.subject.y;
/* 56 */     if (location > this.maxY) {
/* 57 */       location = this.maxY;
/*    */     }
/* 59 */     else if (location < this.minY)
/* 60 */       location = this.minY;
/* 61 */     this.velY = ((location - this.y) * this.snap);
/* 62 */     this.y += this.velY;
/*    */   }
/*    */ }

