/*    */ package com.ProjectStarFlight.spaceshooter.engine;
/*    */ 
/*    */ import java.awt.Graphics2D;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardParticleHandler
/*    */   extends StandardHandler
/*    */ {
/*    */   public final int MAX_PARTICLES;
/*    */   public int dead;
/*    */   public int oldest;
/*    */   public int replace;
/*    */   
/*    */   public StandardParticleHandler(int max)
/*    */   {
/* 19 */     this.MAX_PARTICLES = max;
/* 20 */     this.dead = this.MAX_PARTICLES;
/* 21 */     this.oldest = 0;
/* 22 */     this.replace = this.MAX_PARTICLES;
/*    */     
/*    */ 
/*    */ 
/* 26 */     this.entities = new ArrayList(this.MAX_PARTICLES + 1);
/* 27 */     for (int i = 0; i < this.MAX_PARTICLES; i++)
/*    */     {
/* 29 */       this.entities.add(null);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void tick()
/*    */   {
/* 36 */     long death = -1L;
/*    */     
/*    */ 
/* 39 */     if (this.dead < this.MAX_PARTICLES) {
/* 40 */       for (int i = this.dead; i < this.MAX_PARTICLES; i++)
/*    */       {
/* 42 */         StandardGameObject particle = (StandardGameObject)this.entities.get(i);
/*    */         
/*    */ 
/*    */ 
/* 46 */         if (particle.alive())
/*    */         {
/* 48 */           particle.tick();
/* 49 */           if (((particle.death < death ? 1 : 0) ^ (particle.death < 0L ? 1 : 0) ^ (death < 0L ? 1 : 0)) != 0)
/*    */           {
/* 51 */             this.oldest = i;
/* 52 */             death = particle.death;
/*    */           }
/*    */         }
/*    */         else
/*    */         {
/* 57 */           StandardGameObject swap = (StandardGameObject)this.entities.get(this.dead);
/* 58 */           this.entities.set(i, swap);
/* 59 */           this.entities.set(this.dead++, null);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void render(Graphics2D g2) {
/* 66 */     for (int i = 0; i < this.entities.size(); i++)
/*    */     {
/* 68 */       StandardGameObject particle = (StandardGameObject)this.entities.get(i);
/*    */       
/* 70 */       if ((particle != null) && (particle.alive()))
/* 71 */         particle.render(g2);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addEntity(StandardGameObject particle) {
/* 76 */     if (this.dead == 0)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 83 */       if (this.replace == 0)
/* 84 */         this.replace = this.MAX_PARTICLES;
/* 85 */       this.entities.set(--this.replace, particle);
/* 86 */       return;
/*    */     }
/*    */     
/* 89 */     this.entities.set(--this.dead, particle);
/*    */   }
/*    */   
/*    */ 
/*    */   public void removeEntity(StandardGameObject obj) {}
/*    */   
/*    */ 
/*    */   public int size()
/*    */   {
/* 98 */     return this.MAX_PARTICLES - this.dead;
/*    */   }
/*    */ }

