/*     */ package com.ProjectStarFlight.spaceshooter.engine;
/*     */ 
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import javax.swing.JFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardWindow
/*     */   extends Canvas
/*     */ {
/*     */   private static final long serialVersionUID = 6915741236108516353L;
/*     */   private JFrame frame;
/*     */   private int width;
/*     */   private int height;
/*     */   private String title;
/*     */   
/*     */   public StandardWindow(short width, short height, String title, StandardGame game)
/*     */   {
/*  32 */     this.frame = new JFrame();
/*     */     
/*  34 */     this.frame.setTitle(title);
/*  35 */     this.width = width;
/*  36 */     this.height = height;
/*  37 */     this.title = title;
/*     */     
/*  39 */     this.frame.setMinimumSize(new Dimension(width, height));
/*  40 */     this.frame.setMaximumSize(new Dimension(width, height));
/*  41 */     this.frame.setPreferredSize(new Dimension(width, height));
/*     */     
/*  43 */     this.frame.setResizable(false);
/*  44 */     this.frame.setDefaultCloseOperation(3);
/*  45 */     this.frame.setLocationRelativeTo(null);
/*     */     
/*  47 */     this.frame.add(game);
/*     */     
/*  49 */     this.frame.getContentPane().setSize(new Dimension(width, height));
/*     */     
/*  51 */     this.frame.pack();
/*     */     
/*  53 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   public StandardWindow(short width, short height, String title, Object game)
/*     */   {
/*  58 */     this.frame = new JFrame();
/*     */     
/*  60 */     this.frame.setTitle(title);
/*  61 */     this.width = width;
/*  62 */     this.height = height;
/*  63 */     this.title = title;
/*     */     
/*  65 */     this.frame.setMinimumSize(new Dimension(width, height));
/*  66 */     this.frame.setMaximumSize(new Dimension(width, height));
/*  67 */     this.frame.setPreferredSize(new Dimension(width, height));
/*     */     
/*  69 */     this.frame.setDefaultCloseOperation(3);
/*  70 */     this.frame.setLocationRelativeTo(null);
/*     */     
/*  72 */     this.frame.add((Component)game);
/*     */     
/*  74 */     this.frame.getContentPane().setSize(new Dimension(width, height));
/*     */     
/*  76 */     this.frame.pack();
/*     */     
/*  78 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   public void setBackgroundColor(Color color)
/*     */   {
/*  83 */     this.frame.setBackground(color);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int width()
/*     */   {
/*  90 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int height()
/*     */   {
/*  98 */     return this.height;
/*     */   }
/*     */   
/*     */   public JFrame getFrame() {
/* 102 */     return this.frame;
/*     */   }
/*     */   
/*     */   public void setFrame(JFrame frame) {
/* 106 */     this.frame = frame;
/*     */   }
/*     */   
/*     */   public void setWidth(short width) {
/* 110 */     this.width = width;
/*     */   }
/*     */   
/*     */   public void setHeight(short height) {
/* 114 */     this.height = height;
/*     */   }
/*     */   
/*     */   public String getTitle() {
/* 118 */     return this.title;
/*     */   }
/*     */   
/*     */   public void setTitle(String title) {
/* 122 */     this.frame.setTitle(title);
/*     */   }
/*     */ }

