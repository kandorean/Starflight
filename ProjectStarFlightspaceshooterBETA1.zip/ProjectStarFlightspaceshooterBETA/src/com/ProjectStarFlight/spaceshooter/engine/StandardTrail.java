/*     */ package com.ProjectStarFlight.spaceshooter.engine;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ 
/*     */ public class StandardTrail extends StandardGameObject
/*     */ {
/*   9 */   private float alpha = 1.0F;
/*     */   private float life;
/*     */   private Color color;
/*     */   private String shape;
/*     */   private StandardGameObject obj;
/*  14 */   private boolean isImage = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private StandardHandler stdHandler;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardTrail(double x, double y, double width, double height, Color color, float life, StandardGameObject o, StandardHandler stdHandler, String shape, boolean isImage)
/*     */   {
/*  31 */     super(x, y, (int)width, (int)height);
/*     */     
/*  33 */     this.color = color;
/*  34 */     this.life = life;
/*  35 */     this.shape = shape;
/*  36 */     setId(StandardID.Trail);
/*     */     
/*  38 */     this.stdHandler = stdHandler;
/*  39 */     this.stdHandler.addEntity(this);
/*     */     
/*  41 */     this.isImage = isImage;
/*  42 */     this.obj = o;
/*  43 */     checkNullShape();
/*     */   }
/*     */   
/*     */   private AlphaComposite makeTransparent(float alpha) {
/*  47 */     int type = 3;
/*  48 */     return AlphaComposite.getInstance(type, alpha);
/*     */   }
/*     */   
/*  51 */   public void tick() { if (this.alpha > this.life) {
/*  52 */       this.alpha -= this.life - 0.001F;
/*     */     }
/*  54 */     else if (this.alpha > this.life) {
/*  55 */       this.alpha += this.life - 0.001F;
/*     */     }
/*     */     else {
/*  58 */       this.stdHandler.removeEntity(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void render(Graphics2D g2)
/*     */   {
/*  64 */     g2.setComposite(makeTransparent(this.alpha));
/*  65 */     if ((!this.isImage) && (this.shape != null)) {
/*  66 */       g2.setColor(this.color);
/*  67 */       if (this.shape.equalsIgnoreCase("Circle")) {
/*  68 */         g2.fillOval((int)getX(), (int)getY(), getWidth(), getHeight());
/*     */       } else {
/*  70 */         g2.fillRect((int)getX(), (int)getY(), getWidth(), getHeight());
/*     */       }
/*     */     } else {
/*  73 */       g2.drawImage(this.obj.getCurrentSprite(), (int)getX(), (int)getY(), null);
/*     */     }
/*  75 */     g2.setComposite(makeTransparent(1.0F));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkNullShape()
/*     */   {
/*  83 */     if ((this.shape == null) && (!this.isImage)) {
/*  84 */       System.err.println("Shape is NULL in a Trail");
/*  85 */       this.shape = "Square";
/*     */     }
/*     */   }
/*     */   
/*     */   public float getAlpha()
/*     */   {
/*  91 */     return this.alpha;
/*     */   }
/*     */   
/*     */   public void setAlpha(float alpha)
/*     */   {
/*  96 */     this.alpha = alpha;
/*     */   }
/*     */   
/*     */   public float getLife() {
/* 100 */     return this.life;
/*     */   }
/*     */   
/*     */   public void setLife(float life)
/*     */   {
/* 105 */     this.life = life;
/*     */   }
/*     */   
/*     */   public Color getColor() {
/* 109 */     return this.color;
/*     */   }
/*     */   
/*     */   public void setColor(Color color)
/*     */   {
/* 114 */     this.color = color;
/*     */   }
/*     */   
/*     */   public String getShape() {
/* 118 */     return this.shape;
/*     */   }
/*     */   
/*     */   public void setShape(String shape) {
/* 122 */     this.shape = shape;
/*     */   }
/*     */   
/*     */   public boolean isImage() {
/* 126 */     return this.isImage;
/*     */   }
/*     */   
/*     */   public void setImage(boolean isImage) {
/* 130 */     this.isImage = isImage;
/*     */   }
/*     */ }

