/*    */ package com.ProjectStarFlight.spaceshooter.engine;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class StandardParticle
/*    */   extends StandardGameObject
/*    */ {
/* 18 */   public Color color = Color.red;
/*    */   protected StandardHandler handler;
/*    */   
/*    */   public StandardParticle(double x, double y, double life) {
/* 22 */     super((int)x, (int)y, StandardID.Particle);
/*    */     
/* 24 */     life *= 1.0E9D;
/*    */     
/* 26 */     this.death = (long) (System.nanoTime() + life);
/*    */   }
/*    */   
/*    */   public StandardParticle(double x, double y, StandardHandler handler) {
/* 30 */     super((int)x, (int)y, StandardID.Particle);
/*    */     
/* 32 */     this.handler = handler;
/*    */     
/* 34 */     this.handler.addEntity(this);
/*    */   }
/*    */   
/*    */   public StandardParticle(double x, double y, double life, StandardHandler handler) {
/* 38 */     this(x, y, handler);
/* 39 */     life *= 1.0E9D;
/* 40 */     this.death = (long) (System.nanoTime() + life);
/*    */   }
/*    */   
/*    */   public StandardParticle(double x, double y, double life, StandardHandler handler, Color c) {
/* 44 */     this(x, y, life, handler);
/*    */   }
/*    */ }

