/*    */ package com.ProjectStarFlight.spaceshooter.engine;
/*    */ 
/*    */ import java.awt.Font;
/*    */ import java.awt.GraphicsEnvironment;
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.File;
/*    */ import java.io.PrintStream;
/*    */ import java.util.concurrent.ThreadLocalRandom;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class StdOps
/*    */ {
/*    */   public static int rand(int min, int max)
/*    */   {
/* 28 */     return ThreadLocalRandom.current().nextInt(min, max + 1);
/*    */   }
/*    */   
/*    */   public static double rand(double min, double max) {
/* 32 */     return ThreadLocalRandom.current().nextDouble(min, max + 1.0D);
/*    */   }
/*    */   
/*    */   public static long rand(long min, long max) {
/* 36 */     return ThreadLocalRandom.current().nextLong(min, max + 1L);
/*    */   }
/*    */   
/*    */   public static short rand(short min, short max) {
/* 40 */     return (short)ThreadLocalRandom.current().nextInt(min, max + 1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static BufferedImage loadImage(String path)
/*    */   {
/*    */     try
/*    */     {
/* 50 */       return ImageIO.read(new File(path));
/*    */     } catch (Exception e) {
/* 52 */       e.printStackTrace();
/* 53 */       System.err.println("Error! File could not be read!");
/* 54 */       System.exit(1);
/*    */     }
/*    */     
/* 57 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean mouseOver(int mx, int my, int x, int y, int width, int height)
/*    */   {
/* 71 */     return (mx > x) && (mx < x + width) && (my > y) && (my < y + height);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean mouseOver(int mx, int my, Rectangle rect)
/*    */   {
/* 82 */     return (mx > rect.getX()) && (mx < rect.getX() + rect.getWidth()) && (my > rect.getY()) && (my < rect.getY() + rect.getHeight());
/*    */   }
/*    */   
/*    */   public static Font initFont(String path, float size) {
/* 86 */     Font f = null;
/*    */     try
/*    */     {
/* 89 */       f = Font.createFont(0, new File(path)).deriveFont(size);
/* 90 */       GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 91 */       ge.registerFont(Font.createFont(0, new File(path)));
/*    */     } catch (Exception e) {
/* 93 */       e.printStackTrace();
/* 94 */       return null;
/*    */     }
/* 96 */     return f;
/*    */   }
/*    */ }

