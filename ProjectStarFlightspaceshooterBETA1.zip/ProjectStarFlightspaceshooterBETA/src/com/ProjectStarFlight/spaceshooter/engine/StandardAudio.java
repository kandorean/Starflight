/*     */ package com.ProjectStarFlight.spaceshooter.engine;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import javafx.embed.swing.JFXPanel;
/*     */ import javafx.scene.media.AudioClip;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.Clip;
/*     */ import javax.sound.sampled.DataLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardAudio
/*     */ {
/*     */   private Clip audioClip;
/*     */   private String fileName;
/*     */   private AudioClip sound;
/*     */   private boolean sfx;
/*     */   
/*     */   public StandardAudio(String fileName)
/*     */   {
/*  40 */     this.fileName = fileName;
/*     */     try {
/*  42 */       File audioFile = new File(fileName);
/*  43 */       AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);
/*  44 */       AudioFormat format = audioStream.getFormat();
/*  45 */       DataLine.Info info = new DataLine.Info(Clip.class, format);
/*  46 */       this.audioClip = ((Clip)AudioSystem.getLine(info));
/*  47 */       this.audioClip.open(audioStream);
/*     */     }
/*     */     catch (Exception e) {
/*  50 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public StandardAudio(String fileName, boolean sfx)
/*     */   {
/*  57 */     this.sfx = sfx;
/*  58 */     new JFXPanel();
/*     */     try
/*     */     {
/*  61 */       this.sound = new AudioClip(new File(fileName).toURI().toString());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  65 */       e.printStackTrace();
/*     */     }
/*     */     
/*  68 */     this.sound.setVolume(1.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rAndP()
/*     */   {
/*  77 */     this.audioClip.setFramePosition(0);
/*  78 */     this.audioClip.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void J2DPlay()
/*     */   {
/*  86 */     this.audioClip.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void J2DStop()
/*     */   {
/*  93 */     this.audioClip.stop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void J2DClose()
/*     */   {
/* 101 */     this.audioClip.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isPlaying()
/*     */   {
/* 108 */     return this.audioClip.isRunning();
/*     */   }
/*     */   
/*     */   public void FXPlay()
/*     */   {
/* 113 */     if (this.sound.isPlaying()) {
/* 114 */       return;
/*     */     }
/* 116 */     this.sound.play();
/* 117 */     if (!this.sfx) {
/* 118 */       FXLoop();
/*     */     }
/*     */   }
/*     */   
/*     */   public void adjustFXVolume(double val) {
/* 123 */     this.sound.setVolume(this.sound.getVolume() + val);
/*     */   }
/*     */   
/*     */   public double getFXVolume() {
/* 127 */     return this.sound.getVolume();
/*     */   }
/*     */   
/*     */   public void FXStop()
/*     */   {
/* 132 */     this.sound.stop();
/*     */   }
/*     */   
/*     */   public String getFileName()
/*     */   {
/* 137 */     return this.fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void FXLoop()
/*     */   {
/* 144 */     this.sound.setCycleCount(-1);
/*     */   }
/*     */   
/*     */   public void FXResetVolume() {
/* 148 */     this.sound.setVolume(1.0D);
/*     */   }
/*     */   
/*     */   public boolean isFXPlaying() {
/* 152 */     return this.sound.isPlaying();
/*     */   }
/*     */ }


