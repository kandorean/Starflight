/*     */ package com.ProjectStarFlight.spaceshooter.engine;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StandardDraw
/*     */ {
/*     */   public static Graphics2D Renderer;
/*     */   
/*     */   public static void image(BufferedImage image, double x, double y)
/*     */   {
/*  38 */     Renderer.drawImage(image, (int)x, (int)y, null);
/*     */   }
/*     */   
/*     */   public static void image(BufferedImage image, int x, int y) {
/*  42 */     Renderer.drawImage(image, x, y, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void text(String text, int x, int y, String font, float size, Color color)
/*     */   {
/*  54 */     Font oldFont = Renderer.getFont();
/*  55 */     Color oldColor = Renderer.getColor();
/*     */     
/*  57 */     if ((font != null) && (!font.equals(""))) {
/*  58 */       Renderer.setFont(StdOps.initFont(font, size));
/*     */     } else
/*  60 */       Renderer.setFont(new Font("Arial", 0, (int)size));
/*  61 */     Renderer.setColor(color);
/*  62 */     Renderer.drawString(text, x, y);
/*     */     
/*  64 */     Renderer.setColor(oldColor);
/*  65 */     Renderer.setFont(oldFont);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void text(String text, int x, int y, Font font, float size, Color color)
/*     */   {
/*  72 */     Font oldFont = Renderer.getFont();
/*  73 */     Color oldColor = Renderer.getColor();
/*     */     
/*  75 */     if (font != null) {
/*  76 */       Renderer.setFont(font.deriveFont(size));
/*     */     } else
/*  78 */       Renderer.setFont(new Font("Arial", 0, (int)size));
/*  79 */     Renderer.setColor(color);
/*  80 */     Renderer.drawString(text, x, y);
/*     */     
/*  82 */     Renderer.setColor(oldColor);
/*  83 */     Renderer.setFont(oldFont);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void rect(double x, double y, double width, double height, Color color, boolean fill)
/*     */   {
/*  98 */     if (color == null) {
/*  99 */       color = Color.black;
/*     */     }
/*     */     
/* 102 */     if (fill) {
/* 103 */       Color old = Renderer.getColor();
/* 104 */       Renderer.setColor(color);
/* 105 */       Renderer.fillRect((int)x, (int)y, (int)width, (int)height);
/* 106 */       Renderer.setColor(old);
/*     */     }
/*     */     else {
/* 109 */       Color old = Renderer.getColor();
/* 110 */       Renderer.setColor(color);
/* 111 */       Renderer.drawRect((int)x, (int)y, (int)width, (int)height);
/* 112 */       Renderer.setColor(old);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void circle(double x, double y, double width, double height, Color color, boolean fill) {
/* 117 */     if (color == null) {
/* 118 */       color = Color.black;
/*     */     }
/* 120 */     if (fill) {
/* 121 */       Color old = Renderer.getColor();
/* 122 */       Renderer.setColor(color);
/* 123 */       Renderer.fillOval((int)x, (int)y, (int)width, (int)height);
/* 124 */       Renderer.setColor(old);
/*     */     }
/*     */     else {
/* 127 */       Color old = Renderer.getColor();
/* 128 */       Renderer.setColor(color);
/* 129 */       Renderer.drawOval((int)x, (int)y, (int)width, (int)height);
/* 130 */       Renderer.setColor(old);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void Object(StandardGameObject obj)
/*     */   {
/* 139 */     obj.render(Renderer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void Handler(StandardHandler handler)
/*     */   {
/* 148 */     handler.render(Renderer);
/*     */   }
/*     */   
/*     */ 
/* 152 */   public static Color RANDOM = new Color(StdOps.rand(0, 255), StdOps.rand(0, 255), StdOps.rand(0, 255));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */   public static final Color RED = Color.RED;
/* 159 */   public static final Color PINK = new Color(255, 192, 203);
/* 160 */   public static final Color SALMON_PINK = new Color(255, 145, 164);
/* 161 */   public static final Color CORAL_PINK = new Color(248, 131, 121);
/* 162 */   public static final Color SALMON = new Color(250, 128, 114);
/* 163 */   public static final Color RED_PANTONE = new Color(237, 41, 57);
/* 164 */   public static final Color RED_CRAYOLA = new Color(238, 32, 77);
/* 165 */   public static final Color SCARLET = new Color(255, 36, 0);
/* 166 */   public static final Color RED_IMPERIAL = new Color(237, 41, 57);
/* 167 */   public static final Color INDIAN_RED = new Color(205, 92, 92);
/* 168 */   public static final Color SPANISH_RED = new Color(230, 0, 38);
/* 169 */   public static final Color DESIRE = new Color(234, 60, 83);
/* 170 */   public static final Color LUST = new Color(230, 32, 32);
/* 171 */   public static final Color CARMINE = new Color(150, 0, 24);
/* 172 */   public static final Color RUBY = new Color(224, 17, 95);
/* 173 */   public static final Color CRIMSON = new Color(220, 20, 60);
/* 174 */   public static final Color RUSTY_RED = new Color(218, 44, 67);
/* 175 */   public static final Color FIRE_ENGINE_RED = new Color(206, 32, 41);
/* 176 */   public static final Color CARDINAL_RED = new Color(196, 30, 58);
/* 177 */   public static final Color CHILI_RED = new Color(226, 61, 40);
/* 178 */   public static final Color CORNELL_RED = new Color(179, 27, 27);
/* 179 */   public static final Color FIRE_BRICK = new Color(178, 34, 34);
/* 180 */   public static final Color REDWOOD = new Color(164, 90, 82);
/* 181 */   public static final Color OU_CRIMSON_RED = new Color(153, 0, 0);
/* 182 */   public static final Color DARK_RED = new Color(139, 0, 0);
/* 183 */   public static final Color MAROON = new Color(128, 0, 0);
/* 184 */   public static final Color BARN_RED = new Color(124, 10, 2);
/* 185 */   public static final Color TURKEY_RED = new Color(169, 17, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 191 */   public static Color BLUE = Color.BLUE;
/* 192 */   public static Color BABY_BLUE = new Color(137, 207, 240);
/* 193 */   public static Color LIGHT_BLUE = new Color(176, 216, 230);
/* 194 */   public static Color PERIWINKLE = new Color(204, 204, 255);
/* 195 */   public static Color POWDER_BLUE = new Color(176, 224, 230);
/* 196 */   public static Color MORNING_BLUE = new Color(141, 163, 153);
/* 197 */   public static Color BLUE_MUNSELL = new Color(0, 147, 175);
/* 198 */   public static Color BLUE_PANTONE = new Color(0, 24, 168);
/* 199 */   public static Color BLUE_CRAYOLA = new Color(31, 117, 254);
/* 200 */   public static Color BLUE_MEDIUM = new Color(0, 0, 205);
/* 201 */   public static Color SPANISH_BLUE = new Color(0, 112, 184);
/* 202 */   public static Color LIBERTY = new Color(84, 90, 167);
/* 203 */   public static Color EGYPTIAN_BLUE = new Color(16, 52, 166);
/* 204 */   public static Color ULTRAMARINE = new Color(63, 0, 255);
/* 205 */   public static Color DARK_BLUE = new Color(0, 0, 139);
/* 206 */   public static Color RESOLUTION_BLUE = new Color(0, 35, 185);
/* 207 */   public static Color NAVY_BLUE = new Color(0, 0, 128);
/* 208 */   public static Color MIDNIGHT_BLUE = new Color(25, 25, 112);
/* 209 */   public static Color INDEPENDENCE = new Color(76, 81, 109);
/* 210 */   public static Color SPACE_CADET = new Color(29, 41, 81);
/* 211 */   public static Color CAROLINA_BLUE = new Color(123, 175, 212);
/* 212 */   public static Color DUKE_BLUE = new Color(0, 0, 156);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 218 */   public static Color GREEN = Color.GREEN;
/* 219 */   public static Color ARTICHOKE = new Color(143, 151, 121);
/* 220 */   public static Color ARTICHOKE_GREEN_PANTONE = new Color(75, 111, 68);
/* 221 */   public static Color ASPARAGUS = new Color(135, 169, 107);
/* 222 */   public static Color AVOCADO = new Color(86, 130, 3);
/* 223 */   public static Color FERN_GREEN = new Color(79, 121, 66);
/* 224 */   public static Color FERN = new Color(113, 188, 120);
/* 225 */   public static Color FOREST_GREEN = new Color(34, 139, 34);
/* 226 */   public static Color HOOKER_GREEN = new Color(73, 121, 107);
/* 227 */   public static Color JUNGLE_GREEN = new Color(41, 171, 135);
/* 228 */   public static Color LAUREL_GREEN = new Color(169, 186, 157);
/* 229 */   public static Color LIGHT_GREEN = new Color(144, 238, 144);
/* 230 */   public static Color MANTIS = new Color(116, 195, 101);
/* 231 */   public static Color MOSS_GREEN = new Color(138, 154, 91);
/* 232 */   public static Color DARK_MOSS_GREEN = new Color(74, 93, 35);
/* 233 */   public static Color MYRTLE_GREEN = new Color(49, 120, 115);
/* 234 */   public static Color MINT_GREEN = new Color(152, 251, 152);
/* 235 */   public static Color PINE_GREEN = new Color(1, 121, 111);
/* 236 */   public static Color SAP_GREEN = new Color(0, 158, 96);
/* 237 */   public static Color IRISH_GREEN = new Color(0, 158, 96);
/* 238 */   public static Color ST_PATRICK = IRISH_GREEN;
/* 239 */   public static Color TEA_GREEN = new Color(208, 240, 192);
/* 240 */   public static Color TEAL = new Color(0, 128, 128);
/* 241 */   public static Color DARK_GREEN = new Color(0, 100, 0);
/* 242 */   public static Color GREEN_PANTONE = new Color(0, 173, 131);
/* 243 */   public static Color GREEN_CRAYOLA = new Color(28, 172, 120);
/* 244 */   public static Color ARMY_GREEN = new Color(75, 83, 32);
/* 245 */   public static Color BOTTLE_GREEN = new Color(0, 106, 78);
/* 246 */   public static Color BRIGHT_GREEN = new Color(102, 255, 0);
/* 247 */   public static Color BRIGHT_MINT = new Color(79, 255, 176);
/* 248 */   public static Color BRUNSWICK_GREEN = new Color(27, 77, 62);
/* 249 */   public static Color CELADON = new Color(173, 255, 175);
/* 250 */   public static Color DARK_PASTEL_GREEN = new Color(3, 192, 160);
/* 251 */   public static Color DARTMOUTH_GREEN = new Color(0, 105, 62);
/* 252 */   public static Color EMERALD = new Color(80, 220, 100);
/* 253 */   public static Color GREEN_YELLOW = new Color(173, 255, 47);
/* 254 */   public static Color HARLEQUIN = new Color(63, 255, 0);
/* 255 */   public static Color HUNTER_GREEN = new Color(53, 94, 59);
/* 256 */   public static Color INDIA_GREEN = new Color(19, 136, 8);
/* 257 */   public static Color ISLAMIC_GREEN = new Color(0, 144, 0);
/* 258 */   public static Color JADE = new Color(0, 168, 107);
/* 259 */   public static Color KELLY_GREEN = new Color(75, 187, 23);
/* 260 */   public static Color MIDNIGHT_GREEN = new Color(0, 73, 83);
/* 261 */   public static Color NEON_GREEN = new Color(57, 255, 20);
/* 262 */   public static Color OFFICE_GREEN = new Color(0, 128, 0);
/* 263 */   public static Color PERSIAN_GREEN = new Color(0, 166, 147);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 269 */   public static Color YELLOW = Color.YELLOW;
/* 270 */   public static Color CREAM = new Color(255, 255, 204);
/* 271 */   public static Color YELLOW_MUNSELL = new Color(239, 204, 0);
/* 272 */   public static Color YELLOW_PANTONE = new Color(254, 223, 0);
/* 273 */   public static Color YELLOW_CRAYOLA = new Color(252, 232, 131);
/* 274 */   public static Color UNMELLOW_YELLOW = new Color(255, 255, 102);
/* 275 */   public static Color LEMON = new Color(253, 255, 0);
/* 276 */   public static Color ROYAL_YELLOW = new Color(250, 219, 94);
/* 277 */   public static Color GOLD = new Color(255, 215, 0);
/* 278 */   public static Color CYBER_YELLOW = new Color(255, 211, 0);
/* 279 */   public static Color SAFETY_YELLOW = new Color(238, 210, 2);
/* 280 */   public static Color GOLDENROD = new Color(218, 165, 32);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 286 */   public static Color ORANGE = Color.ORANGE;
/* 287 */   public static Color ORANGE_WHEEL = new Color(255, 127, 0);
/* 288 */   public static Color DARK_ORANGE = new Color(255, 140, 0);
/* 289 */   public static Color ORANGE_PANTONE = new Color(255, 88, 0);
/* 290 */   public static Color ORANGE_CRAYOLA = new Color(255, 117, 56);
/* 291 */   public static Color PEACH = new Color(255, 229, 180);
/* 292 */   public static Color LIGHT_ORANGE = new Color(254, 216, 177);
/* 293 */   public static Color APRICOT = new Color(251, 206, 177);
/* 294 */   public static Color MELON = new Color(253, 188, 180);
/* 295 */   public static Color TEA_ROSE = new Color(248, 131, 121);
/* 296 */   public static Color CARROT_ORANGE = new Color(237, 145, 33);
/* 297 */   public static Color ORANGE_PEEL = new Color(255, 159, 0);
/* 298 */   public static Color PRINCETON_ORANGE = new Color(245, 128, 37);
/* 299 */   public static Color UT_ORANGE = new Color(255, 130, 0);
/* 300 */   public static Color SPANISH_ORANGE = new Color(232, 97, 0);
/* 301 */   public static Color PUMPKIN = new Color(255, 117, 24);
/* 302 */   public static Color VERMILION = new Color(227, 66, 52);
/* 303 */   public static Color TOMATO = new Color(255, 99, 71);
/* 304 */   public static Color BURNT_ORANGE = new Color(191, 87, 0);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 310 */   public static Color PURPLE = new Color(128, 0, 128);
/* 311 */   public static Color ROYAL_PURPLE = new Color(120, 81, 169);
/* 312 */   public static Color RED_VIOLET = new Color(199, 21, 133);
/* 313 */   public static Color PURPLE_MEDIUM = new Color(147, 112, 219);
/* 314 */   public static Color MUNSELL = new Color(159, 0, 197);
/* 315 */   public static Color MAUVE = new Color(224, 176, 255);
/* 316 */   public static Color ORCHID = new Color(218, 112, 214);
/* 317 */   public static Color HELIOTROPE = new Color(223, 115, 255);
/* 318 */   public static Color PHLOX = new Color(223, 0, 255);
/* 319 */   public static Color PURPLE_PIZZAZZ = new Color(254, 78, 218);
/* 320 */   public static Color MULBERRY = new Color(197, 75, 140);
/* 321 */   public static Color PEARLY_PURPLE = new Color(183, 104, 162);
/* 322 */   public static Color PURPUREUS = new Color(154, 78, 174);
/* 323 */   public static Color MARDI_GRAS = new Color(136, 0, 137);
/* 324 */   public static Color PANSY_PURPLE = new Color(120, 24, 74);
/* 325 */   public static Color DARK_PURPLE = new Color(48, 25, 52);
/* 326 */   public static Color VIOLET = new Color(127, 0, 255);
/*     */ }


