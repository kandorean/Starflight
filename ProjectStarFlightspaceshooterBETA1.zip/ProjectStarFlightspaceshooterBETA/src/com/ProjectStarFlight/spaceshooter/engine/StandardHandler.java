/*     */ package com.ProjectStarFlight.spaceshooter.engine;
/*     */ 
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardHandler
/*     */ {
/*     */   public ArrayList<StandardGameObject> entities;
/*     */   public StandardCamera stdCamera;
/*     */   
/*     */   public StandardHandler(StandardCamera stdCamera)
/*     */   {
/*  28 */     this.entities = new ArrayList();
/*  29 */     this.stdCamera = stdCamera;
/*     */   }
/*     */   
/*     */   public StandardHandler() {
/*  33 */     this.entities = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void Object(StandardGameObject obj)
/*     */   {
/*  41 */     obj.tick();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void Handler(StandardHandler handler)
/*     */   {
/*  50 */     handler.tick();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void Add(StandardGameObject obj, StandardHandler stdHandler, int n)
/*     */   {
/*  65 */     for (int i = 0; i < n; i++) {
/*  66 */       stdHandler.addEntity(obj);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tick()
/*     */   {
/*  77 */     for (int i = 0; i < this.entities.size(); i++) {
/*  78 */       ((StandardGameObject)this.entities.get(i)).tick();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void render(Graphics2D g2)
/*     */   {
/*  92 */     int vpo = 300;
/*  93 */     Rectangle cam = null;
/*  94 */     if (this.stdCamera != null) {
/*  95 */       cam = new Rectangle((int)(this.stdCamera.x - vpo - this.stdCamera.vpw), (int)(this.stdCamera.y - this.stdCamera.vph), this.stdCamera.vpw * 2 + vpo * 2, this.stdCamera.vph * 2);
/*     */     }
/*  97 */     for (int i = 0; i < this.entities.size(); i++)
/*     */     {
/*  99 */       StandardGameObject o = (StandardGameObject)this.entities.get(i);
/*     */       
/* 101 */       if ((cam != null) && (
/* 102 */         (o.getBounds().intersects(cam)) || (this.stdCamera == null))) {
/* 103 */         o.render(g2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stdRender(Graphics2D g2)
/*     */   {
/* 114 */     for (int i = 0; i < this.entities.size(); i++) {
/* 115 */       ((StandardGameObject)this.entities.get(i)).render(g2);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addEntity(StandardGameObject obj)
/*     */   {
/* 124 */     this.entities.add(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeEntity(StandardGameObject obj)
/*     */   {
/* 134 */     this.entities.remove(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearEntities()
/*     */   {
/* 143 */     for (int i = 0; i < this.entities.size(); i++)
/*     */     {
/* 145 */       if (((StandardGameObject)this.entities.get(i)).getId() != StandardID.Player) {
/* 146 */         this.entities.remove(i);
/* 147 */         i--;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearAllEntities()
/*     */   {
/* 157 */     this.entities.clear();
/*     */   }
/*     */   
/*     */   public void sort() {
/* 161 */     for (int i = 0; i < this.entities.size(); i++) {
/* 162 */       if (((StandardGameObject)this.entities.get(i)).getId() == StandardID.Player) {
/* 163 */         this.entities.add(0, (StandardGameObject)this.entities.get(i));
/* 164 */         removeEntity((StandardGameObject)this.entities.get(i));
/*     */       }
/*     */       
/* 167 */       if (((StandardGameObject)this.entities.get(i)).getId() == StandardID.Enemy) {
/* 168 */         this.entities.add(1, (StandardGameObject)this.entities.get(i));
/* 169 */         removeEntity((StandardGameObject)this.entities.get(i));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean validCollison(StandardGameObject obj2)
/*     */   {
/* 180 */     return ((obj2.getId() == StandardID.Block) || (obj2.getId() == StandardID.Brick) || 
/* 181 */       (obj2.getId() == StandardID.Obstacle) || (obj2.getId() == StandardID.NPC) || 
/* 182 */       (obj2.getId() == StandardID.Powerup)) && (obj2.getId() != StandardID.Player) && 
/* 183 */       (obj2.getId() != StandardID.Enemy);
/*     */   }
/*     */   
/*     */ 
/*     */   public void checkCollisions() {}
/*     */   
/*     */   public int size()
/*     */   {
/* 191 */     return this.entities.size();
/*     */   }
/*     */   
/*     */   public StandardGameObject get(int i) {
/* 195 */     return (StandardGameObject)this.entities.get(i);
/*     */   }
/*     */   
/*     */   public ArrayList<StandardGameObject> getEntities() {
/* 199 */     return this.entities;
/*     */   }
/*     */   
/*     */   public void addCam(StandardCamera cam)
/*     */   {
/* 204 */     this.stdCamera = cam;
/*     */   }
/*     */ }

