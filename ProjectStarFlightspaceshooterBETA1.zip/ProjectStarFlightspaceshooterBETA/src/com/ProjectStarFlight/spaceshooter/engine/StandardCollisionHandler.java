/*     */ package com.ProjectStarFlight.spaceshooter.engine;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.geom.Rectangle2D;


/*     */ public class StandardCollisionHandler
/*     */   extends StandardHandler
/*     */ {
/*     */   public StandardCollisionHandler(StandardCamera c)
/*     */   {
/*  16 */     this.stdCamera = c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void tick()
/*     */   {
/*  27 */     double[] norm = new double[2];
/*  28 */     int vpo = 300;
/*  29 */     Rectangle cam = new Rectangle((int)(this.stdCamera.x - vpo - this.stdCamera.vpw), (int)(this.stdCamera.y - this.stdCamera.vph), this.stdCamera.vpw * 2 + vpo * 2, this.stdCamera.vph * 2);
/*  30 */     for (int i = 0; i < this.entities.size(); i++)
/*     */     {
/*     */ 
/*  33 */       StandardGameObject obj1 = (StandardGameObject)this.entities.get(i);
/*  34 */       if (obj1.getBounds().intersects(cam))
/*     */       {
/*  36 */         if ((((StandardGameObject)this.entities.get(i)).getId() == StandardID.Player) || 
/*  37 */           (((StandardGameObject)this.entities.get(i)).getId() == StandardID.Enemy) || 
/*  38 */           (((StandardGameObject)this.entities.get(i)).getId() == StandardID.Projectile) || 
/*  39 */           (((StandardGameObject)this.entities.get(i)).getId() == StandardID.Powerup))
/*     */         {
/*  41 */           obj1.standing = false;obj1.falling = false;
/*     */           
/*     */ 
/*  44 */           for (int j = 0; j < this.entities.size(); j++)
/*     */           {
/*  46 */             StandardGameObject obj2 = (StandardGameObject)this.entities.get(j);
/*  47 */             norm[0] = 0.0D;
/*  48 */             norm[1] = 0.0D;
/*     */             
/*     */ 
/*     */ 
/*  52 */             if ((obj1 != obj2) && (obj1.getId() != obj2.ignore) && (obj1.alive) && (obj2.alive))
/*     */             {
/*  54 */               if (((obj2.getId() == StandardID.Block) || (obj2.getId() == StandardID.Brick) || 
/*  55 */                 (obj2.getId() == StandardID.Obstacle) || (obj2.getId() == StandardID.NPC) || 
/*  56 */                 (obj2.getId() == StandardID.Enemy) || (
/*  57 */                 (obj2.getId() == StandardID.Player) && 
/*  58 */                 (obj2.getId() != StandardID.Camera))) && (
/*  59 */                 (obj1.getId() != StandardID.Projectile) || (obj2.getId() != StandardID.Projectile))) {
/*  60 */                 intersection(obj1, obj2, norm);
/*  61 */                 if (norm[1] == -1.0D) {
/*  62 */                   obj1.standing = true;
/*  63 */                 } else if (norm[1] == 1.0D) {
/*  64 */                   obj1.falling = true;
/*     */                 } else {
/*  66 */                   obj1.falling = true;
/*  67 */                   if (norm[0] == 0.0D)
/*     */                     continue;
/*     */                 }
/*  70 */                 double res = obj2.getRestitution();
/*  71 */                 double dot = obj1.velX * norm[0] + obj1.velY * norm[1];
/*  72 */                 if (dot > -1.2D) { obj1.standing = true;
/*     */                 }
/*     */                 
/*  75 */                 obj1.setVelX(obj1.getVelX() - norm[0] * dot * res);
/*  76 */                 obj1.setVelY(obj1.getVelY() - norm[1] * dot * res);
/*  77 */                 obj2.collide(obj1);
/*  78 */                 obj1.collide(obj2);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*  84 */         obj1.tick();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void intersection(StandardGameObject r1, StandardGameObject r2, double[] norm)
/*     */   {
/*  91 */     double x1 = r1.getX() - Math.signum(r1.getVelX());
/*  92 */     double y1 = r1.getY() - Math.signum(r1.getVelY());
/*  93 */     double x2 = r2.getX();
/*  94 */     double y2 = r2.getY();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */     double w1 = r1.width;
/* 106 */     double h1 = r1.height;
/* 107 */     double w2 = r2.width;
/* 108 */     double h2 = r2.height;
/*     */     
/* 110 */     Rectangle2D.Double b1 = new Rectangle2D.Double(x1, y1, w1, h1);
/* 111 */     Rectangle2D.Double b2 = new Rectangle2D.Double(x2, y2, w2, h2);
/* 112 */     Rectangle2D.Double bx = new Rectangle2D.Double(x1, y1, w1, h1);
/*     */     
/* 114 */     if (!b1.intersects(b2))
/*     */     {
/* 116 */       norm[0] = 0.0D;
/* 117 */       norm[1] = 0.0D;
/* 118 */       return;
/*     */     }
/* 120 */     bx.x -= r1.velX;
/* 121 */     b1.y -= r1.velY;
/* 122 */     if (!bx.intersects(b2))
/*     */     {
/* 124 */       norm[0] = (bx.x < b2.x ? -1 : 1);
/* 125 */       norm[1] = 0.0D;
/* 126 */       if (!b1.intersects(b2))
/*     */       {
/* 128 */         norm[1] = (b1.y < b2.y ? -1 : 1);
/*     */       }
/* 130 */       return;
/*     */     }
/* 132 */     if (!b1.intersects(b2))
/*     */     {
/* 134 */       norm[0] = 0.0D;
/* 135 */       norm[1] = (b1.y < b2.y ? -1 : 1);
/* 136 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void Handler(StandardCollisionHandler sh)
/*     */   {
/* 144 */     sh.tick();
/*     */   }
/*     */ }


