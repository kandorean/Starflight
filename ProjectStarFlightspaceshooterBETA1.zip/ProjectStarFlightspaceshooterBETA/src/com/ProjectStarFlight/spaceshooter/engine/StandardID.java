package com.ProjectStarFlight.spaceshooter.engine;

public enum StandardID
{
  Player,  Particle,  Trail,  Enemy,  Wall,  Obstacle,  StandardGameObject,  StandardButton,  Interactor,  Entity,  Weapon,  NPC,  Large,  Multi,  Powerup,  Block,  Brick,  NULL,  Pipe,  Camera,  Skeleton,  Zombie,  Boss,  FinalBoss,  Creature,  Enemy1,  Enemy2,  Enemy3,  Enemy4,  Enemy5,  Enemy6,  Enemy7,  Enemy8,  Enemy9,  Enemy10,  Object,  Projectile,  Cross;
}

