/*     */ package com.ProjectStarFlight.spaceshooter.engine;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardAnimator
/*     */ {
/*     */   public static final byte PRIORITY_1ST = 127;
/*     */   public static final byte PRIORITY_2ND = 63;
/*     */   public static final byte PRIORITY_3RD = 0;
/*     */   public static final byte PRIORITY_4TH = -64;
/*     */   public static final byte PRIORITY_5TH = -128;
/*     */   public ArrayList<BufferedImage> images;
/*  25 */   private byte priority = 0;
/*  26 */   private long counter = 0L;
/*  27 */   private long delay = 1L;
/*  28 */   private long frame = 0L;
/*  29 */   private long time = 0L;
/*     */   
/*     */ 
/*     */   private StandardGameObject object;
/*     */   
/*  34 */   private boolean animating = true;
/*     */   
/*     */   public StandardAnimator(ArrayList<BufferedImage> images, double delay, StandardGameObject o, int priority) {
/*  37 */     this.images = images;
/*  38 */     this.delay = (long) ((delay * 1.0E9D));
/*  39 */     this.object = o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean animate()
/*     */   {
/*  51 */     if ((this.object.activeAnimation != null) && (
/*  52 */       ((this.object.activeAnimation.priority > this.priority) && (this.object.activeAnimation.animating)) || (!this.animating))) {
/*  53 */       return this.frame == this.images.size() - 1;
/*     */     }
/*  55 */     long current = System.nanoTime();
/*  56 */     long interval = current - this.time;
/*  57 */     this.time = current;
/*  58 */     if (interval - this.delay > 0L) {
/*  59 */       this.counter = 0L;
/*     */     } else
/*  61 */       this.counter += interval;
/*  62 */     this.frame = (this.counter / this.delay % this.images.size());
/*  63 */     this.object.setCurrentSprite((BufferedImage)this.images.get((int)this.frame));
/*  64 */     return this.frame == this.images.size() - 1;
/*     */   }
/*     */   
/*     */   public boolean animate(int x)
/*     */   {
/*  69 */     if ((this.object.activeAnimation != null) && (
/*  70 */       ((this.object.activeAnimation.priority > this.priority) && (this.object.activeAnimation.animating)) || (!this.animating))) {
/*  71 */       return this.frame == this.images.size() - 1;
/*     */     }
/*  73 */     long current = System.nanoTime();
/*  74 */     long interval = current - this.time;
/*  75 */     this.time = current;
/*  76 */     if (interval - this.delay > 0L) {
/*  77 */       this.counter = 0L;
/*     */     } else
/*  79 */       this.counter += interval;
/*  80 */     this.frame = (this.counter / this.delay % this.images.size());
/*  81 */     this.object.setCurrentSprite((BufferedImage)this.images.get((int)this.frame));
/*  82 */     return this.frame == x;
/*     */   }
/*     */   
/*     */   public ArrayList<BufferedImage> getImages() {
/*  86 */     return this.images;
/*     */   }
/*     */   
/*     */   public void setImages(ArrayList<BufferedImage> images) {
/*  90 */     this.images = images;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  94 */     this.counter = 0L;
/*  95 */     this.frame = 0L;
/*  96 */     this.time = System.nanoTime();
/*     */   }
/*     */   
/*     */   public long getDelay()
/*     */   {
/* 101 */     return this.delay;
/*     */   }
/*     */   
/*     */   public void setDelay(double delay) {
/* 105 */     this.delay = (long) ((delay * 1.0E9D));
/*     */   }
/*     */   
/*     */   public long getFrame() {
/* 109 */     return this.frame;
/*     */   }
/*     */   
/*     */   public void setFrame(int frame) {
/* 113 */     this.counter = (this.delay * frame);
/* 114 */     this.frame = frame;
/* 115 */     this.time = System.nanoTime();
/*     */   }
/*     */   
/*     */   public boolean isAnimating() {
/* 119 */     return this.animating;
/*     */   }
/*     */   
/*     */   public void setAnimating(boolean animating) {
/* 123 */     this.animating = animating;
/*     */   }
/*     */ }

