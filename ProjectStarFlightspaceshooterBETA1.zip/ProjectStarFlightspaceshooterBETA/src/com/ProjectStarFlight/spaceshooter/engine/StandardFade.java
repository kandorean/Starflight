/*    */ package com.ProjectStarFlight.spaceshooter.engine;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ public class StandardFade
/*    */ {
/*  7 */   private float time = 0.0F;
/*  8 */   private boolean firstColor = true;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Color color1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Color color2;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private double alpha;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public StandardFade(Color c1, Color c2, double alpha)
/*    */   {
/* 35 */     this.color1 = c1;
/* 36 */     this.color2 = c2;
/*    */     
/* 38 */     this.alpha = alpha;
/*    */   }
/*    */   
/*    */   public Color combine()
/*    */   {
/* 43 */     if ((this.time <= 1.0F) && (this.firstColor)) {
/* 44 */       this.time = ((float)(this.time + this.alpha));
/*    */     }
/*    */     else
/*    */     {
/* 48 */       this.firstColor = false;
/*    */     }
/* 50 */     if ((this.time >= 0.0F) && (!this.firstColor)) {
/* 51 */       this.time = ((float)(this.time - this.alpha));
/*    */     } else {
/* 53 */       this.firstColor = true;
/*    */     }
/*    */     
/* 56 */     short r = (short)(int)(this.time * this.color2.getRed() + (1.0F - this.time) * this.color1.getRed());
/* 57 */     short g = (short)(int)(this.time * this.color2.getGreen() + (1.0F - this.time) * this.color1.getGreen());
/* 58 */     short b = (short)(int)(this.time * this.color2.getBlue() + (1.0F - this.time) * this.color1.getBlue());
/*    */     
/* 60 */     if (r > 255) r = 255;
/* 61 */     if (g > 255) g = 255;
/* 62 */     if (b > 255) { b = 255;
/*    */     }
/* 64 */     if (r < 0) r = 0;
/* 65 */     if (g < 0) g = 0;
/* 66 */     if (b < 0) { b = 0;
/*    */     }
/*    */     
/* 69 */     return new Color(r, g, b);
/*    */   }
/*    */ }


