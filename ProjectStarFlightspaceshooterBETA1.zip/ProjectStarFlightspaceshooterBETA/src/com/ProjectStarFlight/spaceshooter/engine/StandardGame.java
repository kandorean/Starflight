/*     */ package com.ProjectStarFlight.spaceshooter.engine;
/*     */ 
/*     */ import com.ProjectStarFlight.spaceshooter.commands.Command;
/*     */ import com.ProjectStarFlight.spaceshooter.input.Keyboard;
/*     */ import com.ProjectStarFlight.spaceshooter.input.Mouse;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import java.awt.image.BufferStrategy;
/*     */ import java.io.PrintStream;
/*     */ import java.util.EventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StandardGame
/*     */   extends Canvas
/*     */   implements Runnable
/*     */ {
/*     */   private static final long serialVersionUID = -7267473597604645224L;
/*     */   public Keyboard keyboard;
/*     */   public Mouse mouse;
/*  42 */   public StandardWindow window = null;
/*     */   
/*     */ 
/*  45 */   private Thread thread = null;
/*  46 */   private boolean running = false;
/*     */   
/*     */ 
/*  49 */   private int currentFPS = 0;
/*  50 */   public boolean consoleFPS = true;
/*  51 */   public boolean titleFPS = true;
/*     */   
/*     */ 
/*  54 */   public static BufferStrategy bufferStrategy = null;
/*     */   
/*     */   public StandardGame(int width, int height, String title) {
/*  57 */     this.window = new StandardWindow((short)width, (short)height, title, this);
/*     */     
/*  59 */     createBufferStrategy(3);
/*     */     
/*  61 */     bufferStrategy = getBufferStrategy();
/*     */     
/*  63 */     this.mouse = new Mouse();
/*  64 */     this.keyboard = new Keyboard();
/*     */     
/*  66 */     addMouseListener(this.mouse);
/*  67 */     addMouseMotionListener(this.mouse);
/*  68 */     addKeyListener(this.keyboard);
/*     */     
/*  70 */     Command.init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardGame(int width, String title)
/*     */   {
/*  79 */     this.window = new StandardWindow((short)width, (short)(width / 16 * 9), title, this);
/*     */     
/*  81 */     createBufferStrategy(3);
/*     */     
/*  83 */     bufferStrategy = getBufferStrategy();
/*     */     
/*  85 */     this.mouse = new Mouse();
/*  86 */     this.keyboard = new Keyboard();
/*     */     
/*  88 */     addMouseListener(this.mouse);
/*  89 */     addMouseMotionListener(this.mouse);
/*  90 */     addKeyListener(this.keyboard);
/*     */     
/*  92 */     Command.init();
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void StartGame()
/*     */   {
/*  98 */     if (this.running) {
/*  99 */       return;
/*     */     }
/* 101 */     this.thread = new Thread(this);
/* 102 */     this.thread.start();
/* 103 */     this.running = true;
/*     */   }
/*     */   
/*     */   public synchronized void StopGame()
/*     */   {
/* 108 */     if (!this.running) {
/* 109 */       return;
/*     */     }
/*     */     try {
/* 112 */       this.thread.join();
/*     */     } catch (InterruptedException e) {
/* 114 */       e.printStackTrace();
/*     */     }
/* 116 */     this.running = false;
/* 117 */     System.exit(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 127 */     requestFocus();
/* 128 */     long lastTime = System.nanoTime();
/* 129 */     double ns = 1.6666666666666666E7D;
/* 130 */     double delta = 0.0D;
/* 131 */     long timer = System.currentTimeMillis();
/* 132 */     int frames = 0;
/* 133 */     int updates = 0;
/* 134 */     while (this.running)
/*     */     {
/* 136 */       boolean renderable = false;
/*     */       
/* 138 */       long now = System.nanoTime();
/* 139 */       delta += (now - lastTime) / ns;
/* 140 */       lastTime = now;
/*     */       
/*     */ 
/* 143 */       while (delta >= 1.0D) {
/* 144 */         Command.tick(this);
/*     */         
/* 146 */         tick();
/*     */         
/* 148 */         delta -= 1.0D;
/* 149 */         updates++;
/*     */         
/* 151 */         renderable = true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */       if (renderable) {
/* 159 */         frames++;
/* 160 */         bufferStrategy = getBufferStrategy();
/* 161 */         StandardDraw.Renderer = (Graphics2D)bufferStrategy.getDrawGraphics();
/*     */         
/*     */ 
/* 164 */         StandardDraw.Renderer.setColor(Color.BLACK);
/* 165 */         StandardDraw.Renderer.fillRect(0, 0, width(), height());
/*     */         
/*     */ 
/* 168 */         render();
/*     */         
/* 170 */         StandardDraw.Renderer.dispose();
/* 171 */         bufferStrategy.show();
/*     */       }
/*     */       
/* 174 */       if (System.currentTimeMillis() - timer > 1000L) {
/* 175 */         timer += 1000L;
/* 176 */         if (this.titleFPS) {
/* 177 */           this.window.setTitle(this.window.getTitle() + " | " + updates + " ups, " + frames + " fps");
/*     */         }
/* 179 */         if (this.consoleFPS)
/* 180 */           System.out.println(this.window.getTitle() + " | " + updates + " ups, " + frames + " fps");
/* 181 */         updates = 0;
/* 182 */         frames = 0;
/*     */       }
/*     */     }
/*     */     
/* 186 */     StopGame();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void tick();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void render();
/*     */   
/*     */ 
/*     */ 
/*     */   public StandardGame getGame()
/*     */   {
/* 202 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addListener(EventListener listener)
/*     */   {
/* 216 */     if ((listener instanceof KeyListener)) {
/* 217 */       addKeyListener((KeyListener)listener);
/*     */     }
/* 219 */     if ((listener instanceof MouseListener)) {
/* 220 */       addMouseListener((MouseListener)listener);
/*     */     }
/* 222 */     if ((listener instanceof MouseMotionListener)) {
/* 223 */       addMouseMotionListener((MouseMotionListener)listener);
/*     */     }
/* 225 */     if ((listener instanceof MouseWheelListener)) {
/* 226 */       addMouseWheelListener((MouseWheelListener)listener);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getFPS() {
/* 231 */     return this.currentFPS;
/*     */   }
/*     */   
/*     */   public int width() {
/* 235 */     return this.window.width();
/*     */   }
/*     */   
/*     */   public int height() {
/* 239 */     return this.window.height();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void framesToConsole(boolean print)
/*     */   {
/* 247 */     this.consoleFPS = print;
/*     */   }
/*     */   
/*     */   public void framesToTitle(boolean print) {
/* 251 */     this.titleFPS = print;
/*     */   }
/*     */   
/*     */   public StandardWindow getWindow()
/*     */   {
/* 256 */     return this.window;
/*     */   }
/*     */   
/*     */   public Keyboard getKeyboard() {
/* 260 */     return this.keyboard;
/*     */   }
/*     */   
/*     */   public void setKeyboard(Keyboard keyboard) {
/* 264 */     this.keyboard = keyboard;
/*     */   }
/*     */   
/*     */   public Mouse getMouse() {
/* 268 */     return this.mouse;
/*     */   }
/*     */   
/*     */   public void setMouse(Mouse mouse) {
/* 272 */     this.mouse = mouse;
/*     */   }
/*     */ }


