/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nb.test.gamepackagev1;
import edu.sjcny.gpv1.*;

/**
 *
 * @author Evan Lilley
 */
public class Starflight extends DrawableAdapter  
{   static Starflight main = new Starflight();
static GameBoard gb = new GameBoard(main, "Project: Starflight");
public static void main(String[]args)
{
    showGameBoard(gb);
}
    
    
}
